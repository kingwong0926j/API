<template>
  <a-layout id="components-layout-demo-top-side-2">

    <a-layout-header class="header">

<!--      left part-->
      <div class="logo">
        <div class="logo-sub">
          <a></a>
        </div>


<!--      <img style="width:44px;height:44px; padding: auto; margin-right: 10px;margin-bottom: 10px;" src="./../../assets/Icon.png"/><span style="color:white; font-size:1.1rem;padding: 18px 0;padding-left:20px">管理控制台</span>-->

      </div>
<!--      right part-->
<!--      <a-menu-->
<!--              theme="dark"-->
<!--              mode="horizontal"-->
<!--              :style="{ lineHeight: '56px' }"-->
<!--      >-->
<!--        <a-menu-item key="1">nav 1</a-menu-item>-->
<!--        <a-menu-item key="2">nav 2</a-menu-item>-->
<!--        <a-menu-item key="3">nav 3</a-menu-item>-->
<!--          <a-sub-menu popupClassName="">-->
<!--                <span slot="title" class="submenu-title-wrapper">-->
<!--                    <a-icon type="setting" />-->
<!--                </span>-->
<!--                    <a-menu-item key="setting:1">Option 1</a-menu-item>-->
<!--                    <a-menu-item key="setting:2">Option 2</a-menu-item>-->

<!--          </a-sub-menu>-->

<!--      </a-menu>-->



      <div style="    position: absolute;right: 1rem;display: flex;">

          <a-popover placement="bottomRight">
<!--              -->
              <template slot="content">
                  <div class="topPartRightIconPoperItem" style="padding: 8px 15px;">
                      <a-icon type="file-unknown" style="margin-right: 5px;"></a-icon>
                      <a>帮助与文档</a>
                  </div>
                  <div class="topPartRightIconPoperItem"style="padding: 8px 15px;">
                      <a-icon type="file-text" style="margin-right: 5px;"></a-icon>
                      <a>工单</a>
                  </div>
              </template>

              <div class="topPartRightIcon" style="width: 44px;height: 55px;text-align: center;">
                  <a-icon type="question-circle" style="color: white;font-size: 14px;vertical-align: middle;line-height: 55px;"/>
              </div>
          </a-popover>
<!--          语言   选中颜色#CFEFFD-->
          <a-popover placement="bottomRight">
              <template slot="content" >
                  <div class="topPartRightIconPoperItem" style="padding: 8px 15px;">
                      <a>English</a>
                  </div>
                  <div class="topPartRightIconPoperItem"style="padding: 8px 15px;background-color:#CFEFFD;">
                      <a>中文</a>
                  </div>
              </template>
              <div class="topPartRightIcon" style="width: 44px;height: 55px;text-align: center;">
                  <a-icon type="global" style="color: white;font-size: 14px;vertical-align: middle;line-height: 55px;"/>
              </div>
          </a-popover>
<!--          -->
          <a-popover placement="bottomRight">
              <template slot="content">

                  <a-tooltip placement="left">
                      <template slot="title">
                          <span class="topPartRightIconPoperItemTitle">当前用户：{{username}}</span>
                      </template>
                      <div class="topPartRightIconPoperItem" style="padding: 8px 15px;">
                          <a-icon type="user" style="margin-right: 5px;"></a-icon>
                          <a>{{username}}</a>
                      </div>
                  </a-tooltip>




                  <div class="topPartRightIconPoperItem" style="padding: 8px 15px;">
                      <a-icon type="logout" style="margin-right: 5px;" />
                      <a @click="logoutBtn">退出</a>
                  </div>


              </template>

              <div class="topPartRightIcon" style="width: 44px;height: 55px;text-align: center;">
                  <a-icon type="user" style="color: white;font-size: 14px;vertical-align: middle;line-height: 55px;"/>
              </div>
          </a-popover>




<!--        <a-icon type="search" style="color: white;font-size: 1.2rem;margin-right: 10px; vertical-align: middle;"/>-->

<!--          question-circle-->
<!--          global-->

<!--        <a-icon type="bell" style="color: white;font-size: 1.2rem;margin-right: 10px;vertical-align: middle;"/>-->
<!--        <a-icon type="user" style=" color: white;font-size: 1.2rem;margin-right: 10px;vertical-align: middle;"/><span style="color: white;">{{username}}</span>-->
<!--        <a-popconfirm placement="rightBottom" okText="确认" cancelText="取消" @confirm="logoutBtn">-->
<!--        <template slot="title">-->
<!--          <p>你确定退出吗？</p>-->
<!--        </template>-->
<!--        <a style="color:white">退出登录</a>-->
<!--      </a-popconfirm>-->
      </div>

    </a-layout-header>


    <a-layout>
      <a-layout-sider width="224"  :style="{height: '100vh', position: 'fixed', left: 0, }" style="background: #fff">

          <div style="padding: 25px;border-bottom: 1px solid #e8e8e8;">

              <a style="color: #5389F5;text-decoration: none;background-color: transparent;outline: none;cursor: pointer;transition: color 0.3s;">

                  <span style="color: #5389F5;line-height: 30px;font-size: 20px;">移动开发平台</span>
              </a>


          </div>
        <a-menu
          mode="inline"
          :defaultSelectedKeys="['1']"
          :defaultOpenKeys="['sub1']"
          :style="{ height: '100%', borderRight: 0 }"
        >

          <a-sub-menu key="sub1">
            <span class="leftHeader" slot="title"><a-icon type="gateway"/>后台服务</span>
            <a-menu-item key="1" @click="toPage(1)">移动网管</a-menu-item>
          </a-sub-menu>
          <a-sub-menu key="sub2">
            <span class="leftHeader" slot="title"><a-icon type="dashboard" />移动分析</span>
            <a-menu-item key="5">option</a-menu-item>
          </a-sub-menu>
          <a-sub-menu key="sub3">
            <span class="leftHeader" slot="title"><a-icon type="code" />代码管理</span>
            <a-menu-item key="9">option1</a-menu-item>
          </a-sub-menu>
          <a-sub-menu key="sub4">
            <span class="leftHeader" slot="title"><a-icon type="notification" />XXX功能</span>
            <a-menu-item key="8">option2</a-menu-item>
          </a-sub-menu>

          <a-sub-menu key="sub5">
            <span class="leftHeader" slot="title"><a-icon type="notification" />XXX功能</span>
            <a-menu-item key="7">option3</a-menu-item>
          </a-sub-menu>



          <a-sub-menu key="sub6">
            <span class="leftHeader" slot="title"><a-icon type="user" />用户管理</span>

            <a-menu-item key="10" @click="toPage(10)">
              用户管理
            </a-menu-item>

          </a-sub-menu>




        </a-menu>
      </a-layout-sider>
      <a-layout :style="{ marginLeft: '224px' }">
        <a-layout-content
          :style="{    margin:'20px',  minHeight: '280px',borderRadius:'4px',overflow: 'initial'}"
        >

            <div style="background-color:#fff;padding:20px; margin-bottom: 20px; padding-bottom: 40px;border-radius: 4px;">
                <router-view :style="{ paddingBottom:'10px',  minHeight: '880px'}"/>
            </div>

        </a-layout-content>
      </a-layout>
    </a-layout>
  </a-layout>
</template>
<script>
import {logout} from './../../service/api'
  export default {
    data() {
      return {
        collapsed: false,
        username:sessionStorage.getItem('username'),
        visible:false
      };
    },
    methods:{
      handleMenuClick(e){
      console.log(e)
      if(e===1){
        this.visible = true
      }
    },
    async logoutBtn(){
      let token = sessionStorage.getItem('X-Access-Token')
      let res = await logout(token)
      if(res.data.code===200){
        sessionStorage.clear()
        this.$router.replace({name:'login'})
      }else{
        alert(res.message)
      }
    },
    toPage(i){
      var _this = this
      switch(i){
        case 1:
          _this.$router.push({name:'gateway'})
        break;
        case 10:
          _this.$router.push({name:'user'})
        break;
      }
    }
    }
  };
</script>

<style>
  #components-layout-demo-top-side-2 .logo {
    width: 224px;
    height: 56px;
    float: left;
    border-right: 1px solid #ffffff29;
    /*position: relative;*/
    /*display: inline-block;*/
    /*margin:0;*/
    /*box-sizing: border-box;*/

  }
  .logo-sub{
    width: 57px;
    height: 30px;
    display: block;
    margin: 0 0;
    box-sizing: border-box;
    padding-top: 5px;
    /*background-color: rgba(0, 0, 0, 0);*/

  }
  .logo-sub a{
    background: url(~@/assets/icon.png) no-repeat 0 -36px;
    height: 56px;
    width: 161px;
    background-size: 99%;
    padding-right: 0;
    margin-left: 24px;
    display: inline-block;

  }
  .ant-layout-header{
    height: 56px !important;
    padding: 0;
    background-color: #252A3D!important;
    /*box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.8);*/
    border-bottom: none;
  }
  .ant-menu-dark, .ant-menu-dark .ant-menu-sub{
    background-color: #252A3D!important;

  }
  .ant-menu-dark.ant-menu-horizontal{
    /*background: #5792e6;*/

  }
  /* .ant-tabs-nav{
    float: left;
  } */
  .ant-tabs-top-bar .ant-tabs-tab-active{
    color: #23AAEB;
    font-weight: bold;

  }
  .ant-tabs-ink-bar-animated{
    background-color: #23AAEB;
  }
  .ant-tabs-tab{
    font-size: 14px;
    font-weight: normal;
  }
  /* .ant-tabs-bar{
    border: 0;
    margin-bottom: 0;
  } */
  /* .ant-tabs-top-bar .ant-tabs-nav-scroll{
      padding-left: 50px;
      padding-top: 20px;
      background-color: #fff;
    } */


  .ant-tabs-right-bar{
    height: 100%!important;
    padding: 3.6% 0;
    padding-bottom: 20%;

    background-color: #D8E3E8;

  }



  .ant-tabs-right-bar .ant-tabs-tab{
    margin: 0!important;
    height: 55px !important;
    line-height: 15px !important;
    color: #3C5269;
    font-size: 15px;
    padding-top: 20px !important;
    padding-bottom: 20px !important;
  }

  .ant-tabs-right-bar .ant-tabs-tab-active {
    background-color: #fff;
    color: #3AB3ED;
    font-size: 15px;

    margin-left: 2px !important;
  }
  .ant-tabs-right-bar .ant-tabs-ink-bar-animated{
    width: 0!important;
    height: 0!important;
  }

  .ant-tabs-right-content{
    padding-right: 0 !important;
    height: 100% !important;
  }


  .ant-table-thead{
    background-color: red;
    background: green;
  }

  .leftHeader{
    color: #3C5269;
    font-size: 14px;
  }

  /*.ant-table-pagination.ant-pagination {*/
  /*  float: right;*/
  /*  margin: 16px 10px;*/
  /*}*/
  .ant-pagination ,.ant-table-pagination{
    margin-right: 52px!important;
  }
  /*.ant-spin-nested-loading{*/
  /*  padding-left: 50px;*/
  /*  padding-right: 50px;*/
  /*!*}*!*/
  /*.ant-table-thead > tr{*/
  /*  padding-left: 50px;*/
  /*}*/
  /*.ant-table-tbody{*/
  /*  padding-left: 50px;*/
  /*}*/
  /*.ant-table-row{*/
  /*  padding-left: 50px;*/
  /*}*/
  /*.ant-table-row-indent indent-level-0{*/
  /*  padding-left: 50px;*/
  /*}*/



  /*.ant-modal-header{*/
  /*  background-color: #D8E3E8;*/
  /*}*/
  .ant-modal-title{
    font-weight: 500;
    font-size: 14px!important;
    color: #3C5269!important;
  }


  .ant-table-footer{
    background-color: #fff;
  }

  th.column-name,
  td.column-name {
    text-align: center !important;
  }

  .ant-checkbox-wrapper{
    font-size: 12px;
    color: rgba(0,0,0,.65);
  }


  .editable-cell {
    position: relative;
  }

  .editable-cell-input-wrapper,
  .editable-cell-text-wrapper {
    padding-right: 24px;
  }

  .editable-cell-text-wrapper {
    padding: 5px 24px 5px 5px;
  }

  .editable-cell-icon,
  .editable-cell-icon-check {
    position: absolute;
    right: 0;
    width: 20px;
    cursor: pointer;
  }

  .editable-cell-icon {
    line-height: 18px;
    display: none;
  }

  .editable-cell-icon-check {
    line-height: 28px;
  }

  .editable-cell:hover .editable-cell-icon {
    display: inline-block;
  }

  .editable-cell-icon:hover,
  .editable-cell-icon-check:hover {
    color: #108ee9;
  }

  .editable-add-btn {
    margin-bottom: 8px;
  }


  .ant-btn-primary{
    background-color: #23AAEB;
  }


    .topPartRightIcon:hover{
        background-color: #1A1B29;
    }
    .ant-popover-inner-content{
        padding: 0;
    }
    .topPartRightIconPoperItem:hover{
        background-color: #E8F9FF;
    }
    .topPartRightIconPoperItem a{
        width: 90px;
        height: 14px;
        display: inline-block;
        color: #666666;
        font-weight: 400;
        font-size: 12px;
    }

  .topPartRightIconPoperItemTitle{
      height: 14px;
      display: inline-block;
      color: #ffffff;
      font-weight: 400;
      font-size: 12px;
  }

  .ant-tabs-large-bar{
      margin-bottom: 0!important;
  }

</style>
