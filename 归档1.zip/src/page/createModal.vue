<template>
    <div>
        <div style="height:30px">
            <a-icon type="caret-left" style="float:left;margin-top: 7px;margin-right: 10px;font-size:20px" @click="backPage"/>
            <span style="float:left;font-size:20px">创建模型</span>
        </div>
        <div>
            <template>
            <a-form :form="form" @submit="handleSubmit">
                <a-form-item label="模型名称" :label-col="{ span: 4 }" :wrapper-col="{ span: 10 }">
                <a-input
                    placeholder="以字母或下划线开始，由字母数字下划线组成"
                />
                </a-form-item>
                <a-form-item label="模型描述" :label-col="{ span: 4 }" :wrapper-col="{ span: 10 }">
                <a-input
                    placeholder="请填写模型描述" 
                />
                </a-form-item>
                <a-form-item label="模型参数" :label-col="{ span: 4 }" :wrapper-col="{ span: 10 }">
                    <a-tabs defaultActiveKey="1.1">
                        <a-tab-pane v-if="showTable" tab="表格" key="1.1">
                            <a-button type="link" @click="changeShow">样本数据编辑</a-button>
                            <a-table :columns="columns" :dataSource="data" :rowSelection="rowSelection" />
                            <a-button type="primary" @click="submit()">提交</a-button>
                        </a-tab-pane>
                        <a-tab-pane v-else tab="表格" key="1.2">
                            <a-button type="link" @click="changeShow">可视化编辑</a-button>
                            <a-textarea :rows="10" placeholder="请输入合法的JSON" v-model="json"/>
                            <a-button type="primary" @click="pasreJson(json)">解析</a-button>
                        </a-tab-pane>
                        <a-tab-pane tab="树形图" key="2" forceRender>Content of Tab Pane 2</a-tab-pane>
                    </a-tabs>
                </a-form-item>
            </a-form>
            </template>
        </div>
    </div>
</template>
<script>
import {resolveJson,createModal} from './../service/api'
const columns = [
    {
      title: '参数名称',
      dataIndex: 'nodeName',
      key: 'nodeName',
    },
    {
      title: '类型',
      dataIndex: 'dataType',
      key: 'dataType',
    },
    {
      title: '默认值',
      dataIndex: 'dataValue',
      key: 'dataValue',
    },
    {
      title: '描述',
      dataIndex: 'level',
      key: 'level',
    },
  ];
  const data = [
    {
		nodeName: "name",
		data: "test",
		level: 1,
		dataType: "java.lang.String",
		dataValue: "#/name"
	}, {
		nodeName: "passwd",
		data: "123456",
		level: 1,
		dataType: "java.lang.String",
		dataValue: "#/passwd"
	}, {
		nodeName: "catalog",
		data: {
			$ref: "$.data.catalog"
		},
		children: [{
			nodeName: "item",
			data: "1",
			level: 2,
			dataType: "java.lang.String",
			dataValue: "#/catalog/item"
		}, {
			nodeName: "prd",
			data: "23",
			level: 2,
			dataType: "java.lang.String",
			dataValue: "#/catalog/prd"
		}],
		level: 1,
		dataType: "Object",
		dataValue: "#/catalog"
	},
  ];
  const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
    },
    onSelect: (record, selected, selectedRows) => {
      console.log(record, seled, selecctetedRows);
    },
    onSelectAll: (selected, selectedRows, changeRows) => {
      console.log(selected, selectedRows, changeRows);
    },
  };
export default {
  data() {
    return {
      formLayout: 'horizontal',
      form: {},
      data,
      columns,
      rowSelection,
      showTable:true,
      json:null,
      tableData:{}
    };
  },
  methods: {
    async pasreJson(e){
      var _this = this 
      JSON.stringify(e)
      console.log(_this.isJSON(e))
      if(_this.isJSON(e)){
        let params = {}
        params.sampleData = JSON.parse(e)
        const res = await resolveJson(params)
        this.data = res.data.children[0].children
        this.tableData.model_data = res.data.children[0].dataValue
        console.log(JSON.stringify(this.data))
        this.showTable = !this.showTable
      }
    },
    submit(){
      this.tableData.model_name = 'test';
      this.tableData.model_desc = '测试';
      console.log(JSON.stringify(this.tableData))
      const res = createModal(this.tableData)
    },
    changeShow(){
      this.showTable = !this.showTable
    },
    handleSubmit(e) {
      e.preventDefault();
      this.form.validateFields((err, values) => {
        if (!err) {
          console.log('Received values of form: ', values);
        }
      });
    },
    backPage(){
            this.$router.go(-1)
        },
    isJSON(str) {
    if (typeof str == 'string') {
        try {
            var obj=JSON.parse(str);
            if(typeof obj == 'object' && obj ){
                console.log('是JSON');
                return true;
            }else{
                return false;
            }
        } catch(e) {
            console.log('error：'+str+'!!!'+e);
            alert('请输入正确JSON')
            return false;
        }
    }
  }
  },
}
</script>
<style lang="less" scoped>
</style>