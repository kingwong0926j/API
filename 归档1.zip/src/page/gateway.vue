<template>
  <div>
    <a-tabs defaultActiveKey="1" :size="size" style="width:100%;text-align: left;" @change="callback" >
      <a-tab-pane tab="API管理" key="1">
         <div style="display: flex;align-items: center;padding: 16px 0;background-color:#fff;">
            <a-button  type="primary" @click="showModal" class="centerPartTitleButton">创建API</a-button>
            <a-button style="margin-left: 25px;margin-right: 25px;" class="centerPartTitleButton">代码生成</a-button>
            <a-button class="centerPartTitleButton"> 更多<a-icon type="down" /> </a-button>
         </div>
         <a-modal
          title="创建API"
          :visible="visible"
          @ok="handleOk"
          :confirmLoading="confirmLoading"
          @cancel="handleCancel"
        >
        <template slot="footer">
              <a-button key="back" @click="handleCancel">取消</a-button>
              <a-button key="submit" type="primary" :loading="loading" @click="handleOk(form)">
                提交
              </a-button>
            </template>
            <template>
  <a-form :form="form">
    <a-form-item
      :label-col="formItemLayout.labelCol"
      :wrapper-col="formItemLayout.wrapperCol"
      label="API类型"
    >
      <a-radio v-model="form.api_type">HTTP</a-radio>
    </a-form-item>
    <a-form-item
      :label-col="formItemLayout.labelCol"
      :wrapper-col="formItemLayout.wrapperCol"
      label="operationType"
    >
      <a-input
        placeholder="请输入"
        v-model="form.operate_type"
      />
    </a-form-item>
    <a-form-item
      :label-col="formItemLayout.labelCol"
      :wrapper-col="formItemLayout.wrapperCol"
      label="API名称"
    >
      <a-input
        placeholder="请输入"
        v-model="form.api_name"
      />
    </a-form-item>
    <!-- <a-form-item
      :label-col="formItemLayout.labelCol"
      :wrapper-col="formItemLayout.wrapperCol"
      label="接入系统"
    >
      <a-input
        placeholder="请输入"
        v-model="form.of_upstream_url"
      />
    </a-form-item> -->
    <a-form-item
      :label-col="formItemLayout.labelCol"
      :wrapper-col="formItemLayout.wrapperCol"
      label="接入系统"
    >
      <a-select  style="width: 236px" @change="handleChange">
      <a-select-option v-for="(item,index) in apiGroupList" :key="index">
        {{item.name}}
      </a-select-option>
    </a-select>
    </a-form-item>
    <a-form-item
      :label-col="formItemLayout.labelCol"
      :wrapper-col="formItemLayout.wrapperCol"
      label="请求Path"
    >
      <a-input
        placeholder="请输入"
        v-model="form.request_path"
      />
    </a-form-item>
  </a-form>
</template>
        </a-modal>
         <template>
        <a-table :columns="columns" :dataSource="data" @change="onChange" style="background-color: white;">
            <span slot="status" slot-scope="text, record">{{record.status==='0'?"关闭":"开通"}}</span>
            <template slot="operation" slot-scope="text, record">
                <a @click="topage(record)" style="color:#5389F5">配置</a><span style="margin:0 6px">|</span><a style="color:#5389F5" @click="deleteApi(record)">删除</a><span style="margin:0 6px">|</span><a style="color:#5389F5">更多</a>
            </template>
        </a-table>
        </template>
        <!-- <a-drawer
        title="基本信息配置"
        width="500"
        placement="right"
        :closable="false"
        @close="onClose"
        :visible="visible1"
        >
        <a-form>
            <a-form-item label="api名称:" >
            <a-input v-model="drawData.apiName" />
            </a-form-item>
             <a-form-item label="接口描述:" >
            <a-input v-model="drawData.operateType" />
            </a-form-item>
            <a-form-item label="接入系统:" >
            <a-input v-model="drawData.ofUpstreamName" />
            </a-form-item>
            <a-form-item label="调用方式:" >
            <a-input v-model="drawData.type" />
            </a-form-item>
            <a-form-item label="报文编码:" >
            <a-input v-model="drawData.code" />
            </a-form-item>
            <a-form-item label="请求路径:">
            <a-input v-model="drawData.ofUpstreamUrl" />
            </a-form-item>
            <a-button @click="handleSubmit" type="primary" :loading="confirmLoading">提交</a-button>
            <a-button @click="handleSubmit" type="primary" :loading="confirmLoading">取消</a-button>
            <span style="color:#5389F5" @click="topage">高级</span>
        </a-form>
        </a-drawer> -->
      </a-tab-pane>
      <a-tab-pane tab="API分组" key="2" style="background-color:#fff;">
          <template>
            <div style = "display: flex;padding: 16px 0;background-color:#fff;">
              <a-button type="primary" @click="showModalGroupCreat" class="centerPartTitleButton" style="width: 100px;">创建API分组</a-button>
              <a-modal
                      :maskClosable = false
                      :closable = false
                      title="创建API分组"
                      width="823px"
                      :visible="visibleGroupCreat"
                      @ok="handleOkGroupCreat"
                      :confirmLoading="confirmLoadingGroupCreat"
                      @cancel="handleCancelGroupCreat"
                      okText="确认" cancelText="取消"
              >
                  <div style="padding: 0 52px; margin-bottom: 5px;">


                      <div style="display: flex; align-items: center;" >
                          <div style="color: #fff;margin-right: 4px;line-height: 1;font-size: 12px;">*</div><div style="color: #3C5269;font-size: 12px;">分组类型：</div>
                          <div>
                              <a-radio-group defaultValue="a" size="small">
                                  <a-radio value="a" :defaultChecked="true" style="color: #3C5269; font-size: 13px;">HTTP</a-radio>
                              </a-radio-group>
                          </div>
                      </div>



                      <div style="margin-top: 27px;">


                          <div style="display: flex; align-items: center;" >

                          <span style="color: #f04134;margin-right: 4px;line-height: 1;font-size: 12px;">*</span><span style="color: #3C5269;font-size: 12px;margin-right:4px;">API分组：</span>

                          <div>
                              <a-input placeholder="字母或下划线开始, 由数字、字母、下划线或减号组成"  style="width: 512px;height: 32px;" v-model="apiName"/>
                          </div>

                          </div>

                      </div>

                      <div style="margin-top: 27px;">


                          <div style="display: flex; align-items: center;" >

                              <span style="color: #f04134;margin-right: 4px;line-height: 1;font-size: 12px;">*</span><span style="color: #3C5269;font-size: 12px;">服务地址：</span>

                              <div>
                                  <a-input placeholder="请输入服务URL,如 http://example.org/"  style="width: 512px;height: 32px;" v-model="apiHost"/>
                              </div>

                          </div>

                      </div>

                      <div style="margin-top: 27px;">


                          <div style="display: flex; align-items: center;" >

                              <span style="color: #fff;margin-right: 4px;line-height: 1;font-size: 12px;">*</span><span style="color: #3C5269;font-size: 12px;">超时时间：</span>

                              <div>
                                  <a-input placeholder="默认3000ms"  style="width: 512px;height: 32px;" addonAfter="ms"/>
                              </div>

                          </div>

                      </div>
                  </div>


              </a-modal>
             </div>
          </template>


          <template>
              <a-table :columns="apiGroupColumns" :dataSource="apiGroupListData" :pagination="paginationApiGroup" :loading="apiGrouploading" @change="onChangeApiGroup" >
                  <template slot="operation" slot-scope="text, record">
<!--                      <a-popconfirm-->
<!--                              title="Are you sure delete this task?"-->
<!--                              @confirm="confirm"-->
<!--                              @cancel="cancel"-->
<!--                              okText="Yes"-->
<!--                              cancelText="No"-->
<!--                      >-->
                          <a href="#"  style="color:#5389F5">详情</a>
<!--                      </a-popconfirm>-->
                      <a-divider type="vertical" />

<!--                      <a-popconfirm-->
<!--                              title="Are you sure delete this task?"-->
<!--                              @confirm="confirm"-->
<!--                              @cancel="cancel"-->
<!--                              okText="Yes"-->
<!--                              cancelText="No"-->
<!--                      >-->
                          <a href="#"  style="color:#5389F5">生成代码</a>
<!--                      </a-popconfirm>-->
                      <a-divider type="vertical" />
                      <a-popconfirm
                              title="Are you sure delete this task?"
                              @confirm="confirmAPIDelete(record.id)"
                              @cancel="cancel"
                              okText="Yes"
                              cancelText="No"
                      >
                          <a href="#"  style="color:#5389F5">删除</a>
                      </a-popconfirm>
                  </template>
              </a-table>


          </template>
      </a-tab-pane>
        <a-tab-pane tab="数据模型" key="3" style="background-color:#fff;">
            <div style="background-color:#fff; height: 70px; width: 100%; ">

<!--                <div style = "display: flex;padding: 16px 0;padding-left: 50px;background-color:#fff;">-->
<!--                    <a-button type="primary" @click="">创建数据模型</a-button>-->

<!--                </div>-->

<!--                <div style="padding: 25px 0;">-->

<!--                    <a-table :columns="sjmxcolumns" :dataSource="sjmxdata" @change="sjmxonChange">-->

<!--                        <template slot="operation" slot-scope="text, record">-->
<!--                            <a-popconfirm-->
<!--                                    v-if="sjmxdata.length"-->
<!--                                    title="Sure to delete?"-->
<!--                                    @confirm="() => onDelete(record.key)"-->
<!--                            >-->
<!--                                <a href="javascript:;">详情 | 删除</a>-->
<!--                            </a-popconfirm>-->
<!--                        </template>-->

<!--                    </a-table>-->


                <div style="display: flex;padding: 16px 0;">
                    <a-button type="primary" @click="toCreatePage" class="centerPartTitleButton" style="width: 100px;">创建数据模型</a-button>
                </div>
            <a-table :columns="sjmxcolumns" :dataSource="modallist" @change="onChange" style="background-color: white;">
                <span slot="status" slot-scope="text, record">{{record.status==='0'?"关闭":"开通"}}</span>
                <template slot="operation" slot-scope="text, record">
                    <a @click="topage(record)" style="color:#5389F5">配置</a><span style="margin:0 6px">|</span><a style="color:#5389F5" @click="deleteApi(record)">删除</a><span style="margin:0 6px">|</span><a style="color:#5389F5">更多</a>
                </template>
            </a-table>
            </div>
      </a-tab-pane>
      <a-tab-pane tab="API分析" key="4">API分析</a-tab-pane>
        <a-tab-pane tab="网关管理" key="5" style="background-color:#fff;" >

            <div class="gatwayPag">
                <a-tabs
                        defaultActiveKey="1"
                        :tabPosition="mode"
                        @prevClick="callback"
                        @nextClick="callback"
                >
                    <a-tab-pane tab="功能开关" key="1">

                        <div class="pagContent">

                            <div class="contentCell" :class="{'noBorder':ipOPen}">
                                <div class="contentCellTitle" style="display: flex;">
                                    <span>IP白名单</span>
                                </div>
                                <div class="contentCellSub">
                                    <div>通过将IP地址列入白名单来限制对服务或路由的访问</div>
                                    <a-switch :defaultChecked = ipSwitch :checked=ipSwitch @change="onChangeGateway('ipwb')" checkedChildren="开" unCheckedChildren="关"/>
                                </div>


                                <div  v-if="ipOPen === true" class="contentDesOpen">
                                    <div class="contentDesOpenItem" style="display: flex;">
                                        <div>
                                            <span v-if="ipListAL.blacklist ==undefined && ipListAL.whitelist == undefined">名单列表：</span>
                                            <span v-if="ipListAL.blacklist !=undefined">黑名单列表：</span>
                                            <span v-if="ipListAL.whitelist !=undefined">白名单列表：</span>
                                        </div>
                                        <div>
                                            <div v-if="ipListAL.blacklist !=undefined" v-for="(item,indexABC) in ipListAL.blacklist" :key="indexABC">
                                                <div>{{item}}</div>

                                            </div>
                                            <div v-if="ipListAL.whitelist !=undefined" v-for="(item,indexABC) in ipListAL.whitelist" :key="indexABC">
                                                <div>{{item}}</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div>
                                        <img src="~@/assets/gatewayedit.png" style="width: 16px; height: 16px;  position: absolute; top: 15px;right: 15px;" @click="ipEdit">

                                    </div>



                                    <a-modal
                                            :maskClosable = false
                                            :closable = false
                                            title="配置白名单"
                                            width="823px"
                                            :visible="visibleIp"
                                            @ok="handleOkIP"
                                            :confirmLoading="confirmLoadingIP"
                                            @cancel="handleCancelIP"
                                            okText="确认" cancelText="取消"
                                    >
                                        <div style="padding: 0 52px; margin-bottom: 5px;">


                                            <div style="display: flex; align-items: center;" >
                                                <div style="color: #f04134;margin-right: 4px;line-height: 1;font-size: 12px;">*</div><div style="color: #3C5269;font-size: 12px;">类型：</div>
                                                <div>
                                                    <a-select defaultValue="白名单" style="width: 160px;height: 32px;" v-model="ipTypeName">
<!--                                                        <a-select-option value="黑名单">黑名单</a-select-option>-->
                                                        <a-select-option value="白名单">白名单</a-select-option>
                                                    </a-select>
                                                </div>
                                            </div>
                                            <div style="margin-left: 50px;padding-top:8px;font-size: 12px;line-height: 15px;color: rgba(0,0,0,.43);">whitelist和blacklist模型在其使用中是互斥的，因为它们提供了互补的方法</div>


                                            <div style="margin-top: 15px;">

                                                <div style="display: flex;">
                                                    <a-button class="editable-add-btn" @click="handleAddip" style="background: #00ABF1; color:#ffffff;font-size: 14px;">增加</a-button>
                                                    <a-input placeholder="0.0.0.0" style="width: 200px;margin-left: 10px;" v-model="ipAddValue"/>
                                                </div>


                                                <a-table  :dataSource="ipdata" :columns="ipcolumns">
                                                    <template slot="name" slot-scope="text, record">
                                                        <editable-cell :text="text" @change="onCellChangeip(record.key, 'name', $event)"/>
                                                    </template>
                                                    <template slot="operation" slot-scope="text, record">
                                                        <a-popconfirm
                                                                v-if="ipdata.length"
                                                                title="确定要删除?"
                                                                @confirm="() => onDeleteip(record.key)"
                                                        >
                                                            <a href="javascript:;" style="color:#23AAEB;">删除</a>
                                                        </a-popconfirm>
                                                    </template>
                                                </a-table>
                                            </div>




                                        </div>


                                    </a-modal>





                                </div>


                            </div>

                            <div class="contentCell">


                                <div class="contentCellTitle" style="display: flex;">
                                    <span>机器人检测</span>
                                </div>
                                <div class="contentCellSub">
                                    <div>保护服务或路由免受大多数常见机器人的攻击</div>
                                    <a-switch :defaultChecked = botSwitch :checked=botSwitch @change="onChangeGateway('bot')" checkedChildren="开" unCheckedChildren="关"/>
                                </div>
                            </div>

                            <div class="contentCell">
                                <div class="contentCellTitle" style="display: flex;">
                                    <span>签名校验</span>
                                </div>
                                <div class="contentCellSub">
                                    <div>对客户端到移动网关的请求进行验签，已验证调用者身份，保证安全</div>
                                    <a-switch :defaultChecked = "false" @change="onChangeGateway" checkedChildren="开" unCheckedChildren="关"/>
                                </div>
                            </div>


                            <div class="contentCell" :class="{'noBorder':limintOPen}">


                                <div class="contentCellTitle" style="display: flex;">
                                    <span>API限流</span>
                                </div>
                                <div class="contentCellSub">
                                    <div>对某一API的访问量进行限制，避免高峰期时后台服务器被压垮</div>
                                    <a-switch :defaultChecked = limitSwitch :checked=limitSwitch @change="onChangeGateway('limit')" checkedChildren="开" unCheckedChildren="关"/>
                                </div>

                                <div  v-if="limintOPen === true" class="contentDesOpen">

                                    <div class="contentDesOpenItem">
                                        <div>限流模式：</div>
                                        <div>开启</div>
                                    </div>
                                    <div style="display: flex;margin-right: 30px;">
                                        <div v-if="limit_config.year !== undefined" class="contentDesOpenItem" style="margin-right: 100px;">
                                            <div>年：</div>
                                            <div>{{(limit_config.year)+"/year"}}</div>
                                        </div>

                                        <div v-if="limit_config.month !== undefined" class="contentDesOpenItem" style="margin-right: 100px;">
                                            <div>月：</div>
                                            <div>{{limit_config.month+"/month"}}</div>
                                        </div>

                                        <div v-if="limit_config.day !== undefined" class="contentDesOpenItem" style="margin-right: 100px;">
                                            <div>日：</div>
                                            <div>{{limit_config.day+"/day"}}</div>
                                        </div>

                                        <div v-if="limit_config.hour !== undefined" class="contentDesOpenItem" style="margin-right: 100px;">
                                            <div>时：</div>
                                            <div>{{limit_config.hour+"/hour"}}</div>
                                        </div>

                                        <div v-if="limit_config.minute !== undefined" class="contentDesOpenItem" style="margin-right: 100px;">
                                            <div>分：</div>
                                            <div>{{limit_config.minute+"/minute"}}</div>
                                        </div>

                                        <div v-if="limit_config.second !== undefined" class="contentDesOpenItem" style="margin-right: 100px;">
                                            <div>秒：</div>
                                            <div>{{limit_config.second+"/second"}}</div>
                                        </div>

                                    </div>

                                    <div>
                                        <img src="~@/assets/gatewayedit.png" style="width: 16px; height: 16px;  position: absolute; top: 15px;right: 15px;" @click="limitEdit">

                                    </div>



                                    <a-modal
                                            :maskClosable = false
                                            :closable = false
                                            title="配置API限流"
                                            width="823px"
                                            :visible="visibleLimit"
                                            @ok="handleOkLimit"
                                            :confirmLoading="confirmLoadingLimit"
                                            @cancel="handleCancelLimit"
                                            okText="确认" cancelText="取消"
                                    >
                                        <div style="padding: 0 52px; margin-bottom: 5px;">



                                            <div style="display: flex; align-items: center;">

                                                <div style="color: #f04134;margin-right: 4px;line-height: 1;font-size: 12px;">*</div><div style="color: #3C5269;font-size: 12px;">必须至少存在一个限制参数</div>

                                            </div>



                                            <div style="display: flex; align-items: center;margin-top: 10px;" >
                                                <div style="color: #3C5269;font-size: 12px; line-height: 22px;">年：</div>
                                                <div style="margin-left: 10px;">
                                                    <a-input-number size="small" :min="0" :max="100000" :defaultValue="0" style="font-size: 12px;" v-model="limitConfigYear"/>
                                                </div>

                                                <div style="font-size: 12px;color: rgba(0,0,0,.43);margin-left: 40px; line-height: 22px;height: 22px;">每年可以发出的HTTP请求数量。</div>
                                            </div>
                                            <div style="display: flex; align-items: center;margin-top: 10px;" >
                                                <div style="color: #3C5269;font-size: 12px; line-height: 22px;">月：</div>
                                                <div style="margin-left: 10px;">
                                                    <a-input-number size="small" :min="0" :max="100000" :defaultValue="0" style="font-size: 12px;" v-model="limitConfigMonth"/>
                                                </div>

                                                <div style="font-size: 12px;color: rgba(0,0,0,.43);margin-left: 40px; line-height: 22px;height: 22px;">每月可以发出的HTTP请求数量。</div>
                                            </div>
                                            <div style="display: flex; align-items: center;margin-top: 10px;" >
                                                <div style="color: #3C5269;font-size: 12px; line-height: 22px;">日：</div>
                                                <div style="margin-left: 10px;">
                                                    <a-input-number size="small" :min="0" :max="100000" :defaultValue="0" style="font-size: 12px;" v-model="limitConfigDay"/>
                                                </div>

                                                <div style="font-size: 12px;color: rgba(0,0,0,.43);margin-left: 40px; line-height: 22px;height: 22px;">每日可以发出的HTTP请求数量。</div>
                                            </div>
                                            <div style="display: flex; align-items: center;margin-top: 10px;" >
                                                <div style="color: #3C5269;font-size: 12px; line-height: 22px;">时：</div>
                                                <div style="margin-left: 10px;">
                                                    <a-input-number size="small" :min="0" :max="100000" :defaultValue="0" style="font-size: 12px;" v-model="limitConfigHour"/>
                                                </div>

                                                <div style="font-size: 12px;color: rgba(0,0,0,.43);margin-left: 40px; line-height: 22px;height: 22px;">每时可以发出的HTTP请求数量。</div>
                                            </div>
                                            <div style="display: flex; align-items: center;margin-top: 10px;" >
                                                <div style="color: #3C5269;font-size: 12px; line-height: 22px;">分：</div>
                                                <div style="margin-left: 10px;">
                                                    <a-input-number size="small" :min="0" :max="100000" :defaultValue="0"  style="font-size: 12px;" v-model="limitConfigMinute"/>
                                                </div>

                                                <div style="font-size: 12px;color: rgba(0,0,0,.43);margin-left: 40px; line-height: 22px;height: 22px;">每分可以发出的HTTP请求数量。</div>
                                            </div>
                                            <div style="display: flex; align-items: center;margin-top: 10px;" >
                                                <div style="color: #3C5269;font-size: 12px; line-height: 22px;">秒：</div>
                                                <div style="margin-left: 10px;">
                                                    <a-input-number size="small" :min="0" :max="100000" :defaultValue="0" style="font-size: 12px;" v-model="limitConfigSecond"/>
                                                </div>

                                                <div style="font-size: 12px;color: rgba(0,0,0,.43);margin-left: 40px; line-height: 22px;height: 22px;">每秒可以发出的HTTP请求数量。</div>
                                            </div>




                                        </div>


                                    </a-modal>





                                </div>


                            </div>


                            <div class="contentCell">

                                <div class="contentCellTitle" style="display: flex;">
                                    <span>API Mock</span>
                                </div>
                                <div class="contentCellSub">
                                    <div>对某一API的返回值进行Mock，以提供特定的响应结果</div>
                                    <a-switch :defaultChecked = "false" @change="onChangeGateway" checkedChildren="开" unCheckedChildren="关"/>
                                </div>
                            </div>


                            <div class="contentCell">


                                <div class="contentCellTitle" style="display: flex;">
                                    <span>API授权</span>
                                </div>
                                <div class="contentCellSub">
                                    <div>授权方使您能够通过配置好的授权接口来控制对API的访问</div>
                                    <a-switch :defaultChecked = "false" @change="onChangeGateway" checkedChildren="开" unCheckedChildren="关"/>
                                </div>
                            </div>


                            <div class="contentCell">

                                <div class="contentCellTitle" style="display: flex;">
                                    <span>数据加密</span>
                                </div>
                                <div class="contentCellSub">
                                    <div>从客户端到移动网关的请求进行加密，确保数据在传输过程中的安全性</div>
                                    <a-switch :defaultChecked = "false" @change="onChangeGateway" checkedChildren="开" unCheckedChildren="关"/>
                                </div>
                            </div>


                            <div class="contentCell" :class="{ 'noBorder': corsOPen === true }">


                                <div class="contentCellTitle" style="display: flex;">
                                    <span>CORS</span>
                                </div>
                                <div class="contentCellSub">
                                    <div>跨域资源共享，根据规则进行跨域访问控制</div>
                                    <a-switch :defaultChecked = corsSwitch :checked=corsSwitch @change="onChangeGateway('CORS')" checkedChildren="开" unCheckedChildren="关"/>
                                </div>



                                <div  v-if="corsOPen === true" class="contentDesOpen">
                                    <div class="contentDesOpenItem">
                                        <div>允许来源：</div>
                                        <div></div>
                                    </div>

                                    <div class="contentDesOpenItem">
                                        <div>允许方法：</div>
                                        <div>{{corsListAL.methods.length?(corsListAL.methods.join("，")):""}}</div>
                                    </div>


                                    <div class="contentDesOpenItem">
                                        <div>允许标头：</div>
                                        <div></div>
                                    </div>

                                    <div class="contentDesOpenItem">
                                        <div>有效期(s)：</div>
                                        <div>0</div>
                                    </div>


                                    <div class="contentDesOpenItem" style="margin-bottom: 0">
                                        <div>允许凭证：</div>
                                        <div>{{corsListAL.credentials === true ? "是":"否"}}</div>
                                    </div>


                                    <div>
                                        <img src="~@/assets/gatewayedit.png" style="width: 16px; height: 16px;  position: absolute; top: 15px;right: 15px;" @click="corsEdit">

                                    </div>



                                    <a-modal
                                            :maskClosable = false
                                            :closable = false
                                            title="配置CORS规则"
                                            width="823px"
                                            :visible="visibleCORS"
                                            @ok="handleOkCORS"
                                            :confirmLoading="confirmLoadingCORS"
                                            @cancel="handleCancelCORS"
                                            okText="确认" cancelText="取消"
                                    >
                                        <div style="padding: 0 52px; margin-bottom: 5px;">


                                            <div style="display: flex; align-items: center;" >
                                                <div style="color: #f04134;margin-right: 4px;line-height: 1;font-size: 12px;">*</div><div style="color: #3C5269;font-size: 12px;">允许来源：</div>
                                                <div>
                                                    <a-input placeholder="*.mydomain.com"  style="width: 512px;height: 32px;" v-model="corsOrigins"/>
                                                </div>
                                            </div>
                                            <div style="margin-left: 70px;padding-top:4px;font-size: 12px;line-height: 15px;color: rgba(0,0,0,.43);">Access-Control-Allow-Origin，可以设置多个，逗号分隔，允许"*"通配符</div>


                                            <div style="margin-top: 27px;">



                                                <span style="color: #f04134;margin-right: 4px;line-height: 1;font-size: 12px;">*</span><span style="color: #3C5269;font-size: 12px;">允许方法：</span>
                                                <a-checkbox-group :options="plainOptions" v-model="checkedList" style="font-size: 12px;" @change="onChange" />

                                                <div style="margin-left: 70px;padding-top:4px;font-size: 12px;line-height: 15px;color: rgba(0,0,0,.43);">Access-Control-Allow-Methods，可以选择多个</div>

                                            </div>

                                            <div style="margin-top: 27px; display: flex;">
                                                <span style="color: #fff;margin-right: 4px;line-height: 1;font-size: 12px;">*</span><span style="color: #3C5269;font-size: 12px;">允许标头：</span>
                                                <a-textarea style="width: 512px;" placeholder="x-cors-field,content-type" :rows="4" v-model="corsHeaders"/>
                                            </div>
                                            <div style="margin-left: 70px;padding-top:4px;font-size: 12px;line-height: 15px;color: rgba(0,0,0,.43);">Access-Control-Allow-Headers，可以设置多个，逗号分隔，允许使用通配符"*"</div>

                                            <div style="margin-top: 27px; display: flex;">
                                                <span style="color: #fff;margin-right: 4px;line-height: 1;font-size: 12px;">*</span><span style="color: #3C5269;font-size: 12px;">公开标头：</span>
                                                <a-textarea style="width: 512px;" placeholder="x-cors-foo,x-cors-bar" :rows="4" v-model="corsExportHeader"/>
                                            </div>
                                            <div style="margin-left: 70px;padding-top:4px;font-size: 12px;line-height: 15px;color: rgba(0,0,0,.43);">Access-Control-Expose-Headers，可以设置多个，逗号分隔，不允许使用通配符"*"</div>

                                            <div style="margin-top: 27px;display: flex; align-items: center;">
                                                <span style="color: #fff;margin-right: 4px;line-height: 30px;font-size: 12px;">*</span><span style="color: #3C5269;font-size: 12px;line-height: 30px;">有效期(s)：</span>


                                                <div>
                                                    <a-input placeholder="0"  style=" width: 78px;" v-model="corsMax_age"/>
                                                </div>

                                            </div>
                                            <div style="margin-left: 70px;padding-top:4px;font-size: 12px;line-height: 15px;color: rgba(0,0,0,.43);">Access-Control-Max-Age，单位秒</div>


                                            <div style="margin-top: 27px;display: flex;">
                                                <span style="color: #fff;margin-right: 4px;line-height: 1;font-size: 12px;">*</span><span style="color: #3C5269;font-size: 12px; line-height: 20px;">允许凭证：</span>
                                                <a-switch :defaultChecked = "false" size="default" @change="onChangeCorsAcc" checkedChildren="开" unCheckedChildren="关"/>

                                            </div>
                                            <div style="margin-left: 70px;padding-top:4px;font-size: 12px;line-height: 15px;color: rgba(0,0,0,.43);">Access-Control-Allow-Credentials</div>


                                        </div>


                                    </a-modal>





                                </div>


                            </div>





                        </div>



                    </a-tab-pane>
                    <a-tab-pane tab="结果码定制" key="2">



                        <div class="pagContent" style="padding: 20px;">

                            <div style="display: flex;align-items: center;">
                                <div style="height:30px;line-height: 30px;font-size: 15px;color: #3C5269;font-weight: bold;margin-right: 16px; ">Locale</div>
                                    <a-select defaultValue="defalt" style="width: 220px;height: 30px;">
                                        <a-select-option value="defalt">defalt</a-select-option>
                                    </a-select>
                            </div>

                            <div style="margin-top: 20px;">
                                <a-table  :dataSource="dataSourceResult" :columns="columnsResult" style="border: 1px solid #E1EBEF;">
                                    <template slot="name" slot-scope="text, record">
<!--                                        <editable-cell :text="text" @change="onCellChange(record.key, 'name', $event)" />-->

                                        <a-select defaultValue="defalt1" style="width: 220px;height: 30px;">
                                            <a-select-option value="defalt1">请选择结果码</a-select-option>
                                            <a-select-option value="defalt2">1001</a-select-option>
                                            <a-select-option value="defalt3">1002</a-select-option>
                                            <a-select-option value="defalt4">1003</a-select-option>

                                        </a-select>

                                    </template>

                                    <template slot="nameSub" slot-scope="text, record">
                                        <a-input placeholder="请填写定制内容替换默认的提示" />
                                    </template>

                                    <template slot="operation" slot-scope="text, record">
                                        <a-popconfirm
                                                v-if="dataSourceResult.length"
                                                title="Sure to delete?"
                                                @confirm="() => onDelete(record.key)"
                                        >
                                            <a href="javascript:;">删除</a>
                                        </a-popconfirm>
                                    </template>

                                    <template slot="footer" slot-scope="currentPageData" style="padding: 0;">
                                        <div @click="handleAdd" style="background-color:#fff; width: 100%;height: 25px; border: 1px solid #D8E3E8;color: #23AAEB;font-size: 12px;line-height: 25px;text-align: center;">
                                           + 添加
                                        </div>
                                    </template>


                                </a-table>


                                <div style="margin-top: 20.9px;margin-left: 50px;">

                                    <div style="width: 90px;height: 28px; background: #23AAEB;border-radius: 2px;border-radius: 2px;color: #ffffff; alignment: center;line-height: 28px;text-align: center;" class="centerPartTitleButton">保存</div>
                                </div>
                            </div>


                        </div>





                    </a-tab-pane>
                    <a-tab-pane tab="操作记录" key="3">

                        <div style="padding: 30px;">

                            <div >

                                <div class="czjlTopPart">

                                    <div style="display: flex; justify-content: space-between;">
                                        <div>
                                            <span style="font-weight: bold;color: #3C5269;font-size:15px;">操作者</span>
                                            <a-input placeholder="" style="width: 250px;height: 28px;border-radius: 2px;margin-left: 25px;"/>
                                        </div>


                                        <div>
                                            <span style="font-weight: bold;color: #3C5269;font-size:15px;">操作对象</span>

                                            <a-select defaultValue="Option1-1" style="width: 250px;height: 28px;border-radius: 2px;margin-left: 25px;">
                                                <a-select-option value="Option1-1">请选择</a-select-option>
                                                <a-select-option value="Option1-2">API</a-select-option>
                                                <a-select-option value="Option1-3">API分组</a-select-option>
                                                <a-select-option value="Option1-4">数据模型</a-select-option>
                                                <a-select-option value="Option1-5">网络配置</a-select-option>
                                            </a-select>

<!--                                            <a-input placeholder="" style="width: 220px;height: 28px;border-radius: 2px;margin-left: 25px;"/>-->
                                        </div>


                                        <div>
                                            <span style="font-weight: bold;color: #3C5269;font-size:15px;">动作</span>
<!--                                            <a-input placeholder="" style="width: 220px;height: 28px;border-radius: 2px;margin-left: 25px;"/>-->
                                            <a-cascader :options="czjloptions" @change="czjlonChange" placeholder="请选择" style="width: 250px;height: 28px;border-radius: 2px;margin-left: 25px;"/>

                                        </div>
                                    </div>

                                    <div style="display: flex; justify-content: space-between;margin-top: 23px;">

                                        <div>
                                            <span style="font-weight: bold;color: #3C5269;font-size:15px;margin-right: 10px;">安全等级</span>
                                            <a-select
                                                    mode="multiple"
                                                    placeholder="可多选"
                                                    @change="handleChange"
                                                    style="width: 250px;height: 28px;border-radius: 2px;"
                                            >
                                                <a-select-option :key="1">普通</a-select-option>
                                                <a-select-option :key="2">限制</a-select-option>
                                                <a-select-option :key="3">危险</a-select-option>
                                                <a-select-option :key="4">高危</a-select-option>
                                                <a-select-option :key="5">其他</a-select-option>

                                            </a-select>

                                        </div>


                                        <div>
                                            <span style="font-weight: bold;color: #3C5269;font-size:15px;">时间范围</span>
                                            <a-range-picker @change="onChange" style="width: 250px;height: 28px;border-radius: 2px;margin-left: 25px;"/>
                                        </div>


                                        <div style="display: flex;width: 280px;justify-content: space-between;height: 28px;align-items: center;">
                                            <div style="width: 90px;height: 28px;background:#23AAEB;border-radius: 2px;color: #fff;line-height: 28px;margin-right: 20px;font-size:14px; text-align: center;" class="centerPartTitleButton">搜索</div>
                                            <div style="width: 90px;height: 28px;border-radius: 2px;border: 1px solid #D8E3E8;color: #3C5269;line-height: 28px;margin-right: 70px;font-size:14px;text-align: center;">搜索</div>

                                        </div>



                                    </div>


                                    <div>

                                    </div>




                                </div>

                                <div class="czjlBottomPart" style="margin-top: 40px;">
                                    <a-table :columns="czjlcolumns" :dataSource="czjldata" @change="czjlonChange" />

                                </div>



                            </div>

                        </div>


                    </a-tab-pane>
                    <a-tab-pane tab="常用工具" key="4">

                        <div style="padding: 30px; ">

                            <div style="background-color:rgba(235,246,251,0.55); padding: 10px; padding-bottom: 40px!important; border-radius: 2px;">

                                <div style="width: 100%;height: 70px;display:flex;">
                                    <span style="font-weight: bold;font-size: 16px;color: #3C5269;margin-left: 10px;margin-top: 25px;">链路分析</span>
                                </div>

                                <div style="width: 100%;height: 1px; background:#D8E3E8;"></div>


                                <div style="display: flex;height: 30px; align-items: center; margin-top: 14px;margin-left: 10px;">
                                    <span style="color: #E02020;line-height: 30px;">*</span><span style="margin-right: 10px;color: #3C5269;font-size: 15px;line-height: 30px;">Traceld</span>
                                    <a-input placeholder="请输入Traceld"  style="border: 0; border: 1px solid #eeeeee; width: 220px;height: 30px;"/>

                                </div>

                            </div>


                        </div>

                    </a-tab-pane>
                </a-tabs>


            </div>



        </a-tab-pane>

    </a-tabs>
  </div>
</template>
<script>
    import {deleteApi,createApi,creatApiGroup,searchApiGroup,apiList,openplugin,createPlugin,globalPluginList,deleteAPIGroup,getModalList} from './../service/api'

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 12 },
};
const formTailLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 14, offset: 4 },
};
const columns = [
    {
      title: 'operationType',
      dataIndex: 'operateType',
      scopedSlots: { customRender: 'operateType' },
    },
    {
      title: '接口名称',
      dataIndex: 'apiName',
      scopedSlots: { customRender: 'apiName' },
    },
    {
      title: '所属系统',
      dataIndex: 'ofUpstreamName',
      scopedSlots: { customRender: 'ofUpstreamName' },
    },
    {
      title: '类型',
      dataIndex: 'apiType',
      scopedSlots: { customRender: 'apiType' },
    },
    {
      title: '状态',
      dataIndex: 'status',
      scopedSlots: { customRender: 'status' },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      scopedSlots: { customRender: 'operation' },
    },

  ];

  const data = [];
const apiGroupColumns = [
    {
        title: '系统名称',
        dataIndex: 'name',
    },
    {
        title: '服务地址',
        dataIndex: 'host',
    },
    {
        title: '类型',
        dataIndex: 'port',
    },
    {
        title: '操作',
        dataIndex: 'operation',
        scopedSlots: { customRender: 'operation' },

    }
];


const apiGroupData = [
    {
        // key: '1',
        systemname: 'elife_backgroud1',
        address: 'http://211.145.31.251:58760/',
        type: 'HTTP'
    },
    {
        // key: '2',
        systemname: 'elife_backgroud2',
        address: 'http://211.145.31.251:58760/',
        type: 'HTTP'
    },
    {
        // key: '3',
        systemname: 'elife_backgroud3',
        address: 'http://211.145.31.251:58760/',
        type: 'HTTP'
    },
    {
        // key: '4',
        systemname: 'elife_backgroud4',
        address: 'http://211.145.31.251:58760/',
        type: 'HTTP'
    },
    {
        // key: '5',
        systemname: 'elife_backgroud5',
        address: 'http://211.145.31.251:58760/',
        type: 'HTTP'
    }
];

  function onChange(pagination, filters, sorter) {
    console.log('params', pagination, filters, sorter);
  }


    //----操作记录表格
    const czjlcolumns = [
        {
            title: '安全等级',
            dataIndex: 'level',
            filters: [
                {
                    text: '普通',
                    value: '普通',
                },
                {
                    text: '限制',
                    value: '限制',
                },

                {
                    text: '危险',
                    value: '危险',
                },

                {
                    text: '高危',
                    value: '高危',
                },

                {
                    text: '其他',
                    value: '其他',
                },

            ],
            // specify the condition of filtering result
            // here is that finding the name started with `value`
            onFilter: (value, record) => record.level.indexOf(value) === 0,
            // sorter: (a, b) => a.level.length - b.level.length,
            // sortDirections: ['descend', 'ascend'],
        },
        {
            title: '时间',
            dataIndex: 'time',
        },

        {
            title: '操作者',
            dataIndex: 'auth',
        },
        {
            title: '操作对象',
            dataIndex: 'object',
            filters: [
                {
                    text: 'API',
                    value: 'API',
                },
                {
                    text: 'API分组',
                    value: 'API分组',
                },
                {
                    text: '数据模型',
                    value: '数据模型',
                },
                {
                    text: '网关配置',
                    value: '网关配置',
                },
            ],
            filterMultiple: true,
            onFilter: (value, record) => record.object.indexOf(value) === 0,
            // sorter: (a, b) => a.object.length - b.object.length,
            // sortDirections: ['descend', 'ascend'],
        },
    ];

    const czjldata = [
        {
            key: '1',
            level: '限制',
            time: '2020-2-20 08:40:23',
            action: '查询加密配置',
            auth:'547899883@qq.com',
            object:'网关配置'
        },

        {
            key: '1',
            level: '高危',
            time: '2020-2-20 08:40:23',
            action: '查询加密配置',
            auth:'547899883@qq.com',
            object:'网关配置'
        },

        {
            key: '2',
            level: '限制',
            time: '2020-2-20 08:40:23',
            action: '查询加密配置',
            auth:'547899883@qq.com',
            object:'API分组'
        },

        {
            key: '3',
            level: '限制',
            time: '2020-2-20 08:40:23',
            action: '查询加密配置',
            auth:'547899883@qq.com',
            object:'API'
        },

        {
            key: '4',
            level: '普通',
            time: '2020-2-20 08:40:23',
            action: '查询加密配置',
            auth:'547899883@qq.com',
            object:'网关配置'
        },
    ];



    function czjlonChange(pagination, filters, sorter) {
        console.log('params', pagination, filters, sorter);
    }

    function sjmxonChange(pagination, filters, sorter) {
        console.log('params', pagination, filters, sorter);
    }
    //---



    //====数据模型首页表格

    const sjmxcolumns = [
        {
            title: '模型名称',
            dataIndex: 'name',
        },
        {
            title: '模型描述',
            dataIndex: 'description',
        },

        {
            title: '操作',
            dataIndex: 'operation',
            scopedSlots: { customRender: 'operation' },

        },
    ];



    const plainOptions = ['GET', 'POST', 'OPTIONS', 'PUT','DELETE','HEAD'];
    const defaultCheckedList = [];



    //IP黑白名单

    const ipcolumns = [
        {
            title: '地址',
            dataIndex: 'name',
            width: '40%',
            scopedSlots: { customRender: 'name' },
        },
        {
            title: '操作',
            dataIndex: 'operation',
            scopedSlots: { customRender: 'operation' },
        },
    ];


    import EditableCell from './../component/layout/EditableCell'
    // import createApi from './../component/createApi'
  export default {
    // components:{
    //     createApi
    // },

      components: {
          EditableCell,
      },
    data() {
      return {
        form:{},
        formItemLayout,
        formTailLayout,
        APIName:'',
        enterSystem:'',
        enterSystem:'',
        APIGroup:'',
        requestPath:'',
        size: 'large',
        data,
        columns,
        apiGroupColumns,
        apiGroupData,
        visible: false,
        visible1:false,
        confirmLoading:false,
        apiname:'',
        operationType:'',
        apiType:'',
        loading:false,
        visibleGroupCreat:false,
          confirmLoadingGroupCreat:false,
          ModalText:'ddddddddddd',
        visible: false,
          apiGroupListData:[],
          apiName:'',
          apiHost:'',
          drawData:{},
          apiGroupList:{},
          mode: 'right',
          corsOPen:false,
          ipOPen:false,
          visibleCORS:false,
          visibleIp:false,
          visibleLimit:false,
          confirmLoadingCORS:false,
          confirmLoadingIP:false,
          confirmLoadingLimit:false,
          //----- cors编辑参数
          corsOrigins:'',
          corsHeaders:'',
          corsExportHeader:'',
          corsMax_age:'',
          corsCredentials:false,
          //-----


          //=====  结果码显示
          dataSourceResult: [
              {
                  key: '0',
                  name: 'Edward King 0',
                  nameSub: '32',
              },
              {
                  key: '1',
                  name: 'Edward King 1',
                  nameSub: '32',
              },
          ],
          countResult: 2,
          columnsResult: [
              {
                  title: '结果码',
                  dataIndex: 'name',
                  width: '30%',
                  scopedSlots: { customRender: 'name' },
                  className: 'column-name',

              },
              {
                  title: '定制提示',
                  dataIndex: 'nameSub',
                  scopedSlots: { customRender: 'nameSub' },
                  className: 'column-nameSub',

              },
              {
                  title: '',
                  dataIndex: 'operation',
                  scopedSlots: { customRender: 'operation' },
              },
          ],
      //    =====

      //    -----操作记录
          czjloptions: [
              {
                  value: 'API',
                  label: 'API',
                  children: [
                      {
                          value: '添加',
                          label: '添加',
                      },
                      {
                          value: '保存',
                          label: '保存',
                      },
                      {
                          value: '删除',
                          label: '删除',
                      },
                      {
                          value: '同步',
                          label: '同步',
                      },
                  ],
              },
              {
                  value: 'API分组',
                  label: 'API分组',
                  children: [
                      {
                          value: '添加',
                          label: '添加',
                      },
                      {
                          value: '批量添加',
                          label: '批量添加',
                      },
                      {
                          value: '保存',
                          label: '保存',
                      },
                      {
                          value: '删除',
                          label: '删除',
                      },
                  ],
              },
              {
                  value: '数据模型',
                  label: '数据模型',
                  children: [
                      {
                          value: '添加',
                          label: '添加',
                      },
                      {
                          value: '保存',
                          label: '保存',
                      },
                      {
                          value: '删除',
                          label: '删除',
                      },
                  ],
              },
              {
                  value: '网关配置',
                  label: '网关配置',
                  children: [
                      {
                          value: '获取加密密钥',
                          label: '获取加密密钥',
                      },
                      {
                          value: '保存加密配置',
                          label: '保存加密配置',
                      },
                      {
                          value: '保存功能开关',
                          label: '保存功能开关',
                      },
                      {
                          value: '保存定制提示',
                          label: '保存定制提示',
                      },
                  ],
              },
          ],


      //    操作记录表格

          czjldata,
          czjlcolumns,
      // 数据模型
          modallist:[],
          sjmxcolumns,
          checkedList: defaultCheckedList,
          plainOptions,
          //ip黑白名单
          ipcolumns,
          ipdata:[],
          ipAddValue:"",
          ipTypeName:"白名单",
          ipArray:[],
          ipType:"",


      //    全局插件列表data
          globalPluginData:[],

          ipSwitch:false,
          ip_pluginid:"",
          botSwitch:false,
          limitSwitch:false,
          limintOPen:false,
          limitEditOr:false,
          corsEditOr:false,
          ipEditOr:false,

          limit_pluginid:"",
          limit_config:{},
          bot_pluginid:"",
          corsSwitch:false,
          cors_pluginid:"",

      //    ip黑白名单已有ip列表
          ipListAL:{},
      //    cors列表展现信息
          corsListAL:{},

      //    API限流 - 配置参数
          limitConfigYear:0,
          limitConfigMonth:0,
          limitConfigDay:0,
          limitConfigHour:0,
          limitConfigMinute:0,
          limitConfigSecond:0,
          params:{
              pageNum:0,
              pageSize:2000
          },


      //APi分组的分页
          paginationApiGroup:{},
          apiGrouploading:false




      };
    },
    async created(){
      const res = await apiList(this.params)
      this.data = res.data.list
      const resModal = await getModalList()
      const apiGroupList = await searchApiGroup({})
      this.apiGroupList  = apiGroupList.data
      console.log(JSON.stringify(apiGroupList))
    },
    methods:{
        onChange,
        czjlonChange,
        sjmxonChange,
        showDrawer(e) {
        this.visible1 = true;
        this.drawData = e
        console.log(JSON.stringify(e))
      },
      toCreatePage(){
          this.$router.push({name:'createModal'})
      },
      async deleteApi(e){
        console.log(e.apiId)
        let param = {}
        param.api_id = e.apiId
        const resDel = await deleteApi(param)
        if(resDel.code===500){
          alert(resDel.message)
        }else if(resDel.code===200){
          alert('删除成功')
        }
        const res = await apiList(this.params)
        this.data = res.data.list
      },
       handleChange(value,option) {
        console.log(option)
        this.form.api_group_id = option.context.apiGroupList[value].id
        this.form.of_upstream_name = option.context.apiGroupList[value].name
        this.form.of_upstream_url = option.context.apiGroupList[value].protocol +'://'+ option.context.apiGroupList[value].host +':'+ option.context.apiGroupList[value].port
      },
      onClose() {
        this.visible1 = false;
      },
      topage(e){
        console.log(JSON.stringify(e))
          this.$router.push({name:'edit',params:e})
      },
      apiNameChange(e){
            console.log(e);
        },
      showModal() {
        this.visible = true;
      },
      async handleOk(e) {
        var _this = this
        // this.form.operate_type='com.wangj';
        // this.form.api_name='测试创建API';
        this.form.api_type='http';
        // this.form.of_upstream_url='http://192.168.22.130:9002';
        // this.form.path='/testcreate1';
        console.log(JSON.stringify(this.form))
        var res = await createApi(this.form)
        if(res.code === 200){
            this.visible = false
            _this.$router.push({name:'edit',params:res.data})
          }else{
            alert(res.message)
          }
      },
      handleCancel(e) {
        console.log('Clicked cancel button');
        this.visible = false;
      },
      handleSubmit(){
        alert('handleSubmit')
      },
      onChange1(e) {
        console.log('radio checked', e.target.value);
      },
      //  创建api分组
      showModalGroupCreat(){
          this.visibleGroupCreat = true;
        },
        async handleOkGroupCreat(e) {
            this.confirmLoadingGroupCreat = true;

            var  _this = this;

            //接口请求

            var params ={
              "url": _this.apiHost,
              "name":_this.apiName
            }
            // var res = await creatApiGroup(params);
            //
            // if(res.code===200 && res !== undefined){
            //     // alert(JSON.stringify(res));
            //     setTimeout(() => {
            //         _this.visibleGroupCreat = false;
            //         _this.confirmLoadingGroupCreat = false;
            //
            //     }, 1000);
            //     _this.requestApiGroupList();
            //
            // }else{
            //     _this.openNotification();
            // }
            await creatApiGroup(params).then(res =>{

                console.log("123456789");
                console.log(JSON.stringify(res));

                if(res.code===200 && res !== undefined) {

                    // alert(JSON.stringify(res));

                    setTimeout(() => {
                        _this.visibleGroupCreat = false;
                        _this.confirmLoadingGroupCreat = false;

                        _this.$message.success("API分组创建成功");

                    }, 1000);
                    _this.requestApiGroupList();

                }else{
                    _this.confirmLoadingGroupCreat = false;
                    _this.$message.error(res.message);
                }
            }).catch(err =>{
                _this.confirmLoadingGroupCreat = false;
                console.log("123456");
                console.log(err);

            });

        },
        handleCancelGroupCreat(e) {
            console.log('Clicked cancel button');
            this.visibleGroupCreat = false;
        },
        //切换页签触发
        callback(key){
            console.log("1111111111111111111111");

            var  _this = this;
          //api分组
          if (key === "2"){

              _this.requestApiGroupList();
              console.log("nininininini");
          }
          //网关管理触发
          if (key === "5"){
              _this.globalPluginListRequest();
          }

        },

        //请求api分组列表
        async requestApiGroupList(paramDefault){

            var  _this = this;
            _this.apiGrouploading = true;
            var params ={
                pageNum:"1",
                pageSize:"10"
            }
            if(paramDefault !== undefined){
                params = paramDefault;
            }
            var res = await searchApiGroup(params);
            // alert(JSON.stringify(res));

            if (res.code === 200 && res.data !== undefined){
                // alert(JSON.stringify(res));
                _this.apiGroupList = res.data.list;
                _this.apiGroupListData = res.data.list;

                _this.apiGrouploading = false;

                const pagination = {};

                pagination.current = res.data.pageNum;
                pagination.total = res.data.total;
                pagination.defaultPageSize = res.data.pageSize;

                _this.paginationApiGroup = pagination;

            }else {
                _this.apiGrouploading = false;

            }
        },
        //APi分组页面分页选择
        onChangeApiGroup(pagination){
            console.log(pagination);

            this.requestApiGroupList({"pageNum":pagination.current,"pageSize":pagination.defaultPageSize});



        },


        openNotification(e) {



            this.$notification.open({
                message: '提示',
                description:
                    e,
                onClick: () => {
                    console.log('Notification Clicked!');
                },
            });
        },
        onChangeGateway(checked){

            if (checked === 'CORS'){
                this.corsOPen = !this.corsOPen;
                this.corsEditOr = false;

                if (this.corsOPen === true){
                    this.visibleCORS = true;
                }else {
                    this.visibleCORS = false;

                    this.handleOkCORS();

                }
            }
            //ip黑白名单
            if (checked === 'ipwb'){
                this.ipOPen = !this.ipOPen;

                this.ipEditOr = false;
                if (this.ipOPen === true){
                    this.visibleIp = true;
                }else {
                    this.visibleIp = false;

                    this.handleOkIP();

                }
            }
            //机器人检测
            if (checked === 'bot'){
                this.botDes();
            }
            if(checked === 'limit'){
                this.limintOPen = !this.limintOPen;

                this.limitEditOr = false;

                if (this.limintOPen === true){
                    this.visibleLimit = true;
                }else {
                    this.visibleLimit = false;
                    this.handleOkLimit();
                }
            }
        },
        corsEdit() {

            this.corsEditOr = true;
            if (this.corsOPen === true){
                this.visibleCORS = true;
            }else {
                this.visibleCORS = false;
            }
        },
        limitEdit(){
            this.limitEditOr = true;

            if (this.limintOPen === true){
                this.visibleLimit = true;
            }else {
                this.visibleLimit = false;
            }
        },

        ipEdit(){

            this.ipEditOr = true;
            if (this.ipOPen === true){
                this.visibleIp = true;
            }else {
                this.visibleIp = false;
            }

        },

        handleOkLimit(){


            var _this = this;

        //    如果一个都没设置 那不行
            if (this.limitConfigYear !== 0 ||this.limitConfigMonth !==0 || this.limitConfigDay !==0 || this.limitConfigHour !== 0 || this.limitConfigMinute !== 0 || this.limitConfigSecond !== 0){
                this.limitDes();
            }else {
                _this.$message.warning("API限流功能必须至少存在一个限制参数才能开启！");

            }


        },

        handleCancelLimit(){
            this.visibleLimit = false;
            this.limintOPen = this.limitSwitch;
            this.confirmLoadingLimit = false;
        },
        async handleOkIP(e){
            this.visibleIp = false;
            this.confirmLoadingIP = true;
            var  _this = this;

            if (this.ipEditOr !== true){
                _this.ipSwitch = !_this.ipSwitch;
            }

            var enabled = (this.ipSwitch === true) ? "true":"false";

            console.log("芝麻开门");
            console.log(this.ipTypeName);
            if (this.ipTypeName === "白名单"){
            this.ipType = "whitelist";
            }else {
            this.ipType = "blacklist";
            }
            var ipArrayA = [];
            for (let i = 0; i < _this.ipdata.length; i++) {
                ipArrayA.push(_this.ipdata[i]["name"]);
            }
            var config = {};
            config[_this.ipType] = ipArrayA;
            var params ={
                "plugin_name": "ip-restriction",
                "enabled":enabled,
                "plugin_type":"0",
                "config":config,
                "plugin_id":_this.ip_pluginid,

                // "plugin_id":"8ea70c65-2f05-479c-aba7-fbc4dfe045ed",
            }

            console.log("请求参数");
            console.log(JSON.stringify(params));


            await createPlugin(params).then(res =>{


                // {"code":200,"message":"ok","data":null}
                console.log("22222222222");
                console.log(JSON.stringify(res));
                if(res.code===200 && res !== undefined){

                    // alert(JSON.stringify(res));




                    var message = "";

                    if (_this.ipEditOr === true){
                        message = (res.message === 'ok' ? "IP黑名单功能修改成功":res.message);
                    }else {

                        if (enabled === "true"){
                            message = (res.message === 'ok' ? "IP黑名单功能开启成功":res.message);
                        }else {
                            message = (res.message === 'ok' ? "IP黑名单功能关闭成功":res.message);
                        }
                    }

                    _this.$message.success(message);

                    _this.ipArray = ipArrayA;

                    console.log("ip检测返回参数如下");
                    console.log(JSON.stringify(_this.ipArray));
                    setTimeout(() => {
                        _this.visibleIp = false;
                        _this.confirmLoadingIP = false;

                        // _this.ipOPen = _this.ipSwitch;

                        _this.globalPluginListRequest();

                    }, 1000);

                }else{
                    _this.confirmLoadingIP = false;
                    _this.ipSwitch = !_this.ipSwitch;
                    _this.ipOPen = _this.ipSwitch;

                    _this.$message.error(res.message);

                }
            }).catch(err =>{
                _this.$message.error(res.message);
                _this.ipSwitch = !_this.ipSwitch;
                _this.ipOPen = _this.ipSwitch;

                console.log("444444");


            });






        },
        handleCancelIP(e){

                this.visibleIp = false;
                this.ipOPen = this.ipSwitch;
                this.confirmLoadingIP = false;

        },

        //cors 编辑之后  提交 触发
        async handleOkCORS(e) {

            console.log("333333333333");

            this.confirmLoadingCORS = true;

            var  _this = this;

            var enabled = this.corsOPen ? "true":"false";

            if (_this.corsEditOr !== true){
                _this.corsSwitch = !_this.corsSwitch;
            }
            var params ={
                "plugin_name": "cors",
                "plugin_type":"0",
                "enabled":enabled,
                "plugin_id":_this.cors_pluginid,
                "config":{
                    "max_age":_this.corsMax_age,
                    "origins":_this.corsOrigins,
                    "methods":_this.checkedList,
                    "headers":_this.corsHeaders,
                    "exposed_headers":_this.corsExportHeader,
                    "credentials":_this.corsCredentials,
                },
            }


            console.log("请求参数");
            console.log(JSON.stringify(params));
            await createPlugin(params).then(res =>{


                // {"code":200,"message":"ok","data":null}
                console.log("22222222222");
                console.log(JSON.stringify(res));
                if(res.code===200 && res !== undefined){

                    // alert(JSON.stringify(res));




                    var message = "";

                    // 先判断是否是修改  因为 只有开启才能修改
                    if (_this.corsEditOr === true){
                        message = (res.message === 'ok' ? "CORS功能修改成功":res.message);
                    }else {

                        if (enabled === "true"){
                            message = (res.message === 'ok' ? "CORS功能开启成功":res.message);
                        }else {
                            message = (res.message === 'ok' ? "CORS功能关闭成功":res.message);
                        }
                    }
                    _this.$message.success(message);



                    setTimeout(() => {
                        _this.visibleCORS = false;
                        _this.confirmLoadingCORS = false;
                        _this.corsOPen = _this.corsSwitch;
                        _this.globalPluginListRequest();

                    }, 1000);

                }else{
                    _this.corsSwitch = !_this.corsSwitch;
                    _this.corsOPen = _this.corsSwitch;

                    _this.$message.error(res.message);

                }
            }).catch(err =>{
                _this.$message.error(res.message);
                _this.corsSwitch = !_this.corsSwitch;
                _this.corsOPen = _this.corsSwitch;

                console.log("444444");


            });





        },
        handleCancelCORS(e){
            this.visibleCORS = false;

        },
        onChangeCorsAcc(changed){
            this.corsCredentials = changed;
        },




        onCellChange(key, dataIndex, value) {
            const dataSource = [...this.dataSourceResult];
            const target = dataSource.find(item => item.key === key);
            if (target) {
                target[dataIndex] = value;
                this.dataSourceResult = dataSource;
            }
        },
        onDelete(key) {
            const dataSource = [...this.dataSourceResult];
            this.dataSourceResult = dataSource.filter(item => item.key !== key);
        },
        handleAdd() {
            const { countResult, dataSourceResult } = this;
            const newData = {
                key: countResult,
                name: `Edward King ${countResult}`,
                age: 32,
                address: `London, Park Lane no. ${countResult}`,
            };
            this.dataSourceResult = [...dataSourceResult, newData];
            this.countResult = countResult + 1;
        },


    //    ip黑白名单

        onCellChangeip(key, dataIndex, value) {
            const dataSource = [...this.ipdata];
            const target = dataSource.find(item => item.key === key);
            if (target) {
                target[dataIndex] = value;
                this.ipdata = dataSource;
            }
        },
        onDeleteip(key) {
            console.log(JSON.stringify(key));
            const dataSource = [...this.ipdata];
            console.log(JSON.stringify(dataSource));

            this.ipdata = dataSource.filter(item => item.key !== key);






        },
        handleAddip() {
            // const { count, ipdata } = this;
            const newData = {
            };
            if (!this.ipAddValue.length){
                return;
            }
            const dataSource = [...this.ipdata];
            const target = dataSource.find(item => item.name === this.ipAddValue);
            if (target){
                this.$message.error("地址已存在，不可添加同一地址！");
                this.ipAddValue = "";
                return;
            }

            newData["name"] = this.ipAddValue;
            newData["key"] = this.ipdata.length;

            this.ipdata = [...ipdata, newData];

            console.log("+++===+++===+++");
            console.log(JSON.stringify(this.ipdata));

            this.ipAddValue = "";

        },


    //    机器人检测

        async botDes(){


            this.botSwitch = !this.botSwitch;
            var  _this = this;

            var enabled = this.botSwitch ? "true":"false";

            var params ={
                "plugin_name": "bot-detection",
                "enabled":enabled,
                "plugin_type":"0",
                "plugin_id":_this.bot_pluginid,

                // "plugin_id":"26eefc67-e1cb-470c-b47f-2e79c4f00b75",
            }



            console.log("机器人检测请求参数");
            console.log(JSON.stringify(params));
            await createPlugin(params).then(res =>{
                // 26eefc67-e1cb-470c-b47f-2e79c4f00b75

                // {"code":200,"message":"ok","data":null}
                console.log("22222222222");
                console.log(JSON.stringify(res));
                if(res.code===200 && res !== undefined){


                    var message = "";
                    if (enabled === "true"){
                        message = (res.message === 'ok' ? "机器人检测功能开启成功":res.message);
                    }else {
                        message = (res.message === 'ok' ? "机器人检测功能关闭成功":res.message);
                    }
                    _this.$message.success(message);


                }else{
                    _this.botSwitch = !_this.botSwitch;

                    _this.$message.error(res.message);

                }
            }).catch(err =>{
                _this.botSwitch = !_this.botSwitch;
                _this.$message.error(res.message);
            });



        },

        //API限流
        async limitDes(){

            this.visibleLimit = false;
            this.confirmLoadingLimit = true;
            if (this.limitEditOr !== true){
                this.limitSwitch = !this.limitSwitch;
            }

            var  _this = this;


            var enabled = this.limitSwitch ? "true":"false";

            var config = {};
            if (_this.limitConfigYear !== 0){
                config["year"] = _this.limitConfigYear;
            }
            if (_this.limitConfigMonth !== 0){
                config["month"] = _this.limitConfigMonth;
            }
            if (_this.limitConfigDay !== 0){
                config["day"] = _this.limitConfigDay;
            }
            if (_this.limitConfigHour !== 0){
                config["hour"] = _this.limitConfigHour;
            }
            if (_this.limitConfigMinute !== 0){
                config["minute"] = _this.limitConfigMinute;
            }
            if (_this.limitConfigSecond !== 0){
                config["second"] = _this.limitConfigSecond;
            }


            var params ={
                "plugin_name": "rate-limiting",
                "enabled":enabled,
                "plugin_type":"0",
                "plugin_id":_this.limit_pluginid,
                "config":config,
            }



            console.log("机器人检测请求参数");
            console.log(JSON.stringify(params));
            await createPlugin(params).then(res =>{
                // 26eefc67-e1cb-470c-b47f-2e79c4f00b75

                // {"code":200,"message":"ok","data":null}
                console.log("22222222222");
                console.log(JSON.stringify(res));
                if(res.code===200 && res !== undefined){

                    var message = "";


                    if (this.limitEditOr === true){
                        message = (res.message === 'ok' ? "API限流功能修改成功":res.message);
                    }else {

                        if (enabled === "true"){
                            message = (res.message === 'ok' ? "API限流功能开启成功":res.message);
                        }else {
                            message = (res.message === 'ok' ? "API限流功能关闭成功":res.message);
                        }
                    }



                    _this.$message.success(message);


                    setTimeout(() => {
                        _this.visibleLimit = false;
                        _this.confirmLoadingLimit = false;

                        _this.globalPluginListRequest();

                    }, 1000);

                }else{
                    _this.$message.error(res.message);
                    _this.limitSwitch = !_this.limitSwitch;
                    _this.limintOPen = _this.limitSwitch;

                }
            }).catch(err =>{
                _this.limitSwitch = !_this.limitSwitch;
                _this.limintOPen = _this.limitSwitch;
                _this.$message.error(res.message);
            });



        },
        //获取全局插件列表
        async globalPluginListRequest(){

            var  _this = this;

            await globalPluginList().then(res =>{

                console.log("22222222222");
                console.log(JSON.stringify(res));

                if(res.code===200 && res !== undefined){

                    _this.globalPluginData = res.data;


                    var ipJsonString = "";
                    var corsJsonString = "";
                    var limitJsonString = "";

                    for (let i = 0; i < _this.globalPluginData.length; i++) {

                        var item = _this.globalPluginData[i];
                        if (item.pluginName === "bot-detection"){

                            _this.botSwitch = (item.enabled === "true" ? true:false);
                            _this.bot_pluginid = item.pluginId;
                        }


                        if (item.pluginName === "rate-limiting"){

                            _this.limitSwitch = (item.enabled === "true" ? true:false);
                            _this.limintOPen = _this.limitSwitch;
                            _this.limit_pluginid = item.pluginId;
                            limitJsonString = item.config;
                        }

                        if (item.pluginName === "ip-restriction"){


                            _this.ipSwitch = (item.enabled === "true" ? true:false);

                            _this.ipOPen = _this.ipSwitch;
                            _this.ip_pluginid = item.pluginId;
                            ipJsonString = item.config;
                        }

                        if (item.pluginName === "cors"){
                            _this.corsSwitch = (item.enabled === "true" ? true:false);
                            _this.corsOPen = _this.corsSwitch;
                            _this.cors_pluginid = item.pluginId;
                            corsJsonString = item.config;
                        }



                    }

                    console.log("101010101010101010");

                    //将json字符串转成对象
                    if (ipJsonString.length){
                        _this.ipListAL =  JSON.parse(ipJsonString);
                    }
                    if (corsJsonString.length){
                        _this.corsListAL = JSON.parse(corsJsonString);
                    }
                    if (limitJsonString.length){
                        _this.limit_config = JSON.parse(limitJsonString);
                    }


                    //
                    if (_this.limit_config.year != undefined){
                        _this.limitConfigYear =_this.limit_config.year;
                    }else {
                        _this.limitConfigYear = 0;
                    }

                    if (_this.limit_config.month != undefined){
                        _this.limitConfigMonth =_this.limit_config.month;
                    }else {
                        _this.limitConfigMonth = 0;
                    }

                    if (_this.limit_config.day != undefined){
                        _this.limitConfigDay =_this.limit_config.day;
                    }else {
                        _this.limitConfigDay = 0;
                    }

                    if (_this.limit_config.hour != undefined){
                        _this.limitConfigHour =_this.limit_config.hour;
                    }else {
                        _this.limitConfigHour = 0;
                    }

                    if (_this.limit_config.minute != undefined){
                        _this.limitConfigMinute =_this.limit_config.minute;
                    }else {
                        _this.limitConfigMinute = 0;
                    }

                    if (_this.limit_config.second != undefined){
                        _this.limitConfigSecond =_this.limit_config.second;
                    }else {
                        _this.limitConfigSecond = 0;
                    }
                    console.log("55555");
                    console.log(JSON.stringify(_this.ipListAL));
                    console.log(_this.ipListAL.whitelist);
                    console.log(ipJsonString);
                    //
                    // if (_this.ipListAL.blacklist.length){
                    //     console.log("3333333");
                    //
                    //     for (let i = 0; i < _this.ipListAL.blacklist.length; i++) {
                    //         const {ipdata } = this;
                    //         const newData = {
                    //         };
                    //         newData["name"] = _this.ipListAL.blacklist[i];
                    //
                    //         this.ipdata = [...ipdata, newData];
                    //     }
                    // }

                    if (_this.ipListAL.whitelist !== undefined){
                        console.log("4444");

                        for (let i = 0; i < _this.ipListAL.whitelist.length; i++) {
                            const {ipdata } = _this;
                            const newData = {
                            };
                            newData["name"] = _this.ipListAL.whitelist[i];
                            newData["key"] = i;

                            _this.ipdata = [...ipdata, newData];
                        }
                    }



                    console.log("转换之后——————+++");
                    console.log(JSON.stringify(_this.ipListAL));

                    console.log(_this.ipSwitch);






                    setTimeout(() => {

                    }, 1000);

                }else{
                    _this.openNotification(res.message);

                }
            }).catch(err =>{
                // _this.openNotification(res.message);
            });

        },

        //删除API分组接口
        async confirmAPIDelete(e){

            // deleteAPIGroup

            var  _this = this;

            var enabled = this.limitSwitch ? "true":"false";

            var params ={
                "id":e,
            }

            console.log("删除api分组请求参数");
            console.log(JSON.stringify(params));
            await deleteAPIGroup(params).then(res =>{
                // 26eefc67-e1cb-470c-b47f-2e79c4f00b75

                // {"code":200,"message":"ok","data":null}
                console.log("222222222333");
                console.log(JSON.stringify(res));


                if(res.code===200 && res !== undefined){
                    _this.$message.success('API分组删除成功');

                    _this.requestApiGroupList();

                }else{
                    _this.$message.error(res.message);

                }
            }).catch(err =>{
                _this.$message.error(res.message);
            });


        },

        confirm(){

        },

    }
  };
</script>
<style lang="less" scoped>

.ant-modal-header {
        background-color: #D8E3E8;

        #rcDialogTitle0{
            color: #3C5269;
            font-size: 18px;
            font-weight: bold;
        }
    }
    .ant-btn-primary{
        background-color: #23AAEB;
    }
    .ant-modal-footer{
        div{
            display: flex;
            :nth-child(1){
                /*margin-left: 70px;*/
            }
        }
    }
    .ant-modal-footer{
        padding-left: 70px;
        height: 70px;
        border: 0;
    }

    /*.ant-btn{*/
    /*    width: 90px;*/
    /*    text-align: center;*/
    /*    span{*/
    /*        padding: auto;*/
    /*    }*/
    /*}*/
    .ant-tabs-tab-active{
        background-color: #23AAEB;
    }
    .ant-tabs-tab{
        font-size: 14px;
    }

    .gatwayPag{

        background-color: #fff;

    }

    /*.ant-list-item-meta-title{*/
    /*    alignment: left;*/
    /*}*/

    .pagContent{
        /*padding: 3%;*/
        width: 100%;
        /*height: 100%;*/
        background-color: #fff;
    }

    .pagContent .contentCell{
        width: 100%;
        padding: 20px;
        /*margin-bottom: 2%;*/
        border-bottom: 1px solid #D8E3E8;
    }

    .pagContent .contentCell .contentCellTitle{
        color: #3C5269;
        font-size: 14px;
        font-weight: bold;
        width: 10%;
        height: 2.5%;
        margin-bottom: 0.7%;

    }
    .pagContent .contentCell .contentCellSub{

        display: flex;
        justify-content: space-between;
        height: 2.1%;
        margin-bottom: 1.3%;

    }

    .contentDesOpen{
        background-color: #f5f6f7;
        border-radius: 4px;
        padding: 15px;
        margin-top: 11px;
        position: relative;
    }
    .contentDesOpen .contentDesOpenItem{
        display: flex;
        align-items: center;
        margin-bottom: 10px;
        :nth-child(1){
            color: #7B8896;
            font-size: 12px;
        }
        :nth-child(2){
            color: #3C5269;
            font-size: 12px;
        }
    }

    .contentCellSub > div{
        color: #7B8896;
        font-size: 12px;
    }


    .ant-switch-checked {
        background-color: #3AB3ED;
    }
  .ant-tabs-nav{
    float: left !important;
  }

    .noBorder{
        border-bottom: 0!important;
    }

    .centerPartTitleButton{
        height: 26px;width: 75px;font-size: 12px;font-weight: 500;background-color:rgb(16, 142, 233);
        color: #ffffff;
    }


    /**/

</style>
