<template>
    <div>
        <template>
            <div style="background-color:#fff; padding: 20px 25px; height: 110px;">
                <span style="float:left;font-size:20px;color:#3C5269;width:100%;text-align:left;">用户管理</span>

                <a-button style="float:left;margin-top:10px;margin-bottom: 15px;" type="primary" icon="plus" @click="showModal">添加用户</a-button>

            </div>

        <a-modal title="添加用户" v-model="visible">
            <template slot="footer">
              <!-- <span style="float: left;"><span style="color:red">*</span>为必输项</span> -->
              <a-button key="back" @click="handleCancel">取消</a-button>
              <a-button key="submit" type="primary"  @click="handleOk(form)">
                提交
              </a-button>
            </template>
            <!-- <adduser-form></adduser-form> -->
            <a-form :form="form">
              <a-form-item
                label="用户名" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }" 
              >
                <a-input
                  v-model="form.username"
                  placeholder="请输入用户名"
                />
              </a-form-item>
              <a-form-item
                label="密码" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }" 
              >
                <a-input-password
                  placeholder="请输入..."
                  v-model="form.password"
                />
              </a-form-item>
              <a-form-item
                label="邮箱" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }" 
              >
                <a-input
                  placeholder="请输入..."
                  type='email'
                  v-model="form.email"
                />
              </a-form-item>
              <a-form-item
                label="电话" :label-col="{ span: 5 }" :wrapper-col="{ span: 12 }" 
              >
                <a-input
                  placeholder="请输入..."
                  v-model="form.phone"
                />
              </a-form-item>
            </a-form>
        </a-modal>
        </template>

      <a-table :rowKey="record => record.userId" style=" margin-top:20px; margin-left: 25px; margin-right: 25px; background-color:#fff;" bordered :dataSource="dataSource" :pagination="pagination" :columns="columns" :loading="loading">
      <a-pagination v-model="current" :total="50" />
      <span slot="userType" slot-scope="text, record">{{formatUserType('00')}}</span>
      <span slot="status" slot-scope="text, record">{{formatStatus(record.status)}}</span>
       <template slot="operation" slot-scope="text, record">
        <div>
          <a-button type="primary" @click="showModify(record)">
            修改密码
          </a-button>
          <a-modal v-model="visible1" title="编辑" >
            <template slot="footer">
              <a-button key="back" @click="handleCancel">取消</a-button>
              <a-button key="submit" type="primary" :loading="loading" @click="submit(form1)">
                修改
              </a-button>
            </template>
            <a-form :form="form1">
              <a-form-item
                label="修改密码" :required="bool"  
              >
                <a-input
                  placeholder="请输入..."
                  v-model="form1.password"
                />
              </a-form-item>
            </a-form>
          </a-modal>
        </div>
      </template>
    </a-table>
    </div>
</template>
<script>
import {userAdd,userList} from './../service/api'
const columns = [
     {
      title: '用户名',
      dataIndex: 'username',
      scopedSlots: { customRender: 'userName' },
    },
    {
      title: '用户类型',
      dataIndex: 'userType',
      scopedSlots: { customRender: 'userType' },
    },
    {
      title: '用户昵称',
      dataIndex: 'nickname',
      scopedSlots: { customRender: 'nickname' },
    },
     {
      title: '邮箱',
      dataIndex: 'email',
      scopedSlots: { customRender: 'email' },
    },
     {
      title: '电话',
      dataIndex: 'phonenumber',
      scopedSlots: { customRender: 'phoneNumber' },
    },
     {
      title: '性别',
      dataIndex: 'sex',
      scopedSlots: { customRender: 'sex' },
    },
    {
      title: '创建人',
      dataIndex: 'createBy',
      scopedSlots: { customRender: 'createBy' },
    },
    {
      title: '操作',
      dataIndex: 'operation',
      scopedSlots: { customRender: 'operation' },
    },
  ];
export default {
    data(){
        return{
            pagination: {},
            current:1,
            visible: false,
            form:{},
            bool:true,
            columns,
            loading:false,
            dataSource:[],
            form1:{},
            visible1:false,
            params:{
              pageNum:0,
              pageSize:2000
            }
        }
    },
    async created(){
      const res = await userList(this.params);
      this.dataSource = res.data.list
    },
    methods:{
 
      showModal() {
        this.visible = true;
      },
      handleCancel(e) {
        this.visible = false;
        this.form = {
            username:"",
            userType:"",
            nickname:"",
            email:"",
            phonenumber:"",
            sex:"",
            password:"",
            createBy:admin,
            selectedroles:"",
        }
    },
      handleOk(e){
          var _this = this;
          e.userType='00';
          e.selectrole= '00';
          e.createBy = sessionStorage.getItem('username')
          console.log(JSON.stringify(e))
           var res = userAdd(e).then(res =>{
              if(res.code === 200){
                this.visible = false;
                alert('添加用户成功')
                userList().then(res =>{
                  _this.dataSource = res.data
                });
            }else{
              alert('添加用户失败，请重试')
              this.visible = false;
          }
          })
      },
      formatUserType(num){
        switch(num){
        case '00':
          return '系统用户'
        break;
        case '10':
          return '商户管理员用户'
        break;
        case '20':
          return '商户成员用户'
        break;
      }
      },
    }
}
</script>>