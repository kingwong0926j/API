<template>
  <div class="main" style="height:100%">
    <div id="userLayout" :class="['user-layout-wrapper']">
    <div class="container">
      <div class="top">
        <div class="header">
          <a href="/">
            <img src="~@/assets/EB.png" class="logo" alt="logo">
            <span class="title">API Manager Platform</span>
          </a>
        </div>
        <div class="desc">
          ACI provide API gateway service
        </div>
      </div>
      <a-form  class="user-layout-login">
      <a-tabs
        :activeKey="customActiveKey"
        :tabBarStyle="{ textAlign: 'center', borderBottom: 'unset' }">
        <a-tab-pane key="tab1" tab="账号密码登陆">
          <a-form-item>
            <a-input
              size="large"
              type="text"
              placeholder="请输入账户名 / admin"
              v-model='userName'
              >
              <a-icon slot="prefix" type="user" :style="{ color: 'rgba(0,0,0,.25)' }"/>
            </a-input>
          </a-form-item>

          <a-form-item>
            <a-input
              size="large"
              type="password"
              autocomplete="false"
              placeholder="密码 / 111111"
              v-model='passWord'>
              <a-icon slot="prefix" type="lock" :style="{ color: 'rgba(0,0,0,.25)' }"/>
            </a-input>
          </a-form-item>


        </a-tab-pane>
      </a-tabs>

      <a-form-item>
        <a-checkbox>自动登陆</a-checkbox>
      </a-form-item>

      <a-form-item style="margin-top:24px">
        <a-button
          size="large"
          type="primary"
          htmlType="submit"
          class="login-button"
          @click.stop.prevent="handleSubmit">确定
        </a-button>
      </a-form-item>
    </a-form>


      <div class="footer">
        <div class="copyright">
          Copyright &copy; 2019 <a href="http://www.ebchinatech.com/" target="_blank">ACI worldwide</a> 出品
        </div>
      </div>
    </div>
    </div>
  </div>
</template>

<script>
  import Vue from 'vue'
  import {login,queryPermissionsByUser} from './../service/api'

  export default {
    data () {
      return {
        customActiveKey: "tab1",
        userName:'',
        passWord:'',
        userInfo:{
          userName:'admin',
          passWord:'123456'
        }

      }
    },
    created () {
    },
    methods: {
     async  handleSubmit(){
        var params ={
          username:this.userName,
          password:this.passWord
        }
        var res = await login(params)
        if(res.code===200){
          let token = res.data.token 
          sessionStorage.setItem("token", 'true');
          sessionStorage.setItem("X-Access-Token",token)
          sessionStorage.setItem("username",params.username)
          this.$router.replace({name:'home'})
        }else{
          alert(res.message)
        }
      }
    }
  }
</script>

<style lang="scss" scoped>

  .user-layout-login {
    margin-left:38%;
    width: 24%;
    label {
      font-size: 14px;
    }

    .getCaptcha {
      display: block;
      width: 100%;
      height: 40px;
    }

    .forge-password {
      font-size: 14px;
    }

    button.login-button {
      padding: 0 15px;
      font-size: 16px;
      height: 40px;
      width: 100%;
    }

    .user-login-other {
      text-align: left;
      margin-top: 24px;
      line-height: 22px;

      .item-icon {
        font-size: 24px;
        color: rgba(0,0,0,.2);
        margin-left: 16px;
        vertical-align: middle;
        cursor: pointer;
        transition: color .3s;

        &:hover {
          color: #1890ff;
        }
      }

      .register {
        float: right;
      }
    }
  }
#userLayout.user-layout-wrapper {
    height: 100%;

    &.mobile {
      .container {
        .main {
          max-width: 368px;
          width: 98%;
        }
      }
    }

    .container {
      width: 100%;
      min-height: 100%;
      background: #f0f2f5 url(~@/assets/background.svg) no-repeat 50%;
      background-size: 100%;
      padding: 110px 0 144px;
      position: relative;

      a {
        text-decoration: none;
      }

      .top {
        text-align: center;

        .header {
          height: 44px;
          line-height: 44px;

          .badge {
            position: absolute;
            display: inline-block;
            line-height: 1;
            vertical-align: middle;
            margin-left: -12px;
            margin-top: -10px;
            opacity: 0.8;
          }

          .logo {
            height: 44px;
            vertical-align: top;
            margin-right: 16px;
            border-style: none;
          }

          .title {
            font-size: 33px;
            color: rgba(0, 0, 0, .85);
            font-family: "Chinese Quote", -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Helvetica Neue", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            font-weight: 600;
            position: relative;
            top: 2px;
          }
        }
        .desc {
          font-size: 14px;
          color: rgba(0, 0, 0, 0.45);
          margin-top: 12px;
          margin-bottom: 40px;
        }
      }

      .main {
        min-width: 260px;
        width: 368px;
        margin: 0 auto;
        height: 100%;
      }

      .footer {
        position: absolute;
        width: 100%;
        bottom: 0;
        padding: 0 16px;
        margin: 48px 0 24px;
        text-align: center;

        .links {
          margin-bottom: 8px;
          font-size: 14px;
          a {
            color: rgba(0, 0, 0, 0.45);
            transition: all 0.3s;
            &:not(:last-child) {
              margin-right: 40px;
            }
          }
        }
        .copyright {
          color: rgba(0, 0, 0, 0.45);
          font-size: 14px;
        }
      }
    }
  }
</style>
<style>
  .valid-error .ant-select-selection__placeholder{
    color: #f5222d;
  }
</style>