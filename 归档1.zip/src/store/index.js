import Vue from 'vue'
import Vuex from 'vuex'
import {queryPermissionsByUser} from '../service/api'


Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    permissionList: [],
  },
  mutations: {
  },
  actions: {
  }
})