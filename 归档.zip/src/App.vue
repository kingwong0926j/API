<template>
  <div id="app">
    <div style="height:100%" v-if="this.$route.name=='login'">
      <router-view/>
    </div>
    <div style="height:100%" v-else>
      <router-view style="height:100%">
      <slider-bar>
      </slider-bar>
      </router-view>
    </div>
  </div>
</template>

<script>
import sliderBar from './component/layout/sliderBar'
export default {
  name: 'App',
  components:{
    sliderBar
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  width: 100%;
  height: 100%
}
.ant-modal-mask{
  background-color: rgba(0,0,0,0.1) !important;
}
</style>
