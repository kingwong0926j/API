<template>
    <div>
        <div style="height:20px">
            <a-icon type="caret-left" style="float:left;margin-top: 7px;margin-right: 10px;font-size:20px" @click="backPage"/>
            <div v-if="showTitle">
            <span style="float:left;font-size:20px">{{form.apiName}}</span>
            <a-icon type="edit" style="float:left;font-size:20px;margin-left:10px;" @click="showInputTitle"/>
            </div>
            <div v-else style="float:left">
                <a-input placeholder="" style="float:left" v-model="form.apiName" />
                <a-icon type="check" style="position: absolute;font-size: 20px;margin-left: 10px;" @click="showInputTitle"/>
            </div>
            <a-switch checkedChildren="开" unCheckedChildren="关" v-model="checked" style="float:right" @change="openClose"/>
        </div>
        <!-- 基本信息卡片展示 -->
        <a-card title="基本信息" style="text-align: left;margin-top:20px">
        <a v-if="showmsg" @click="changeShow" slot="extra">修改</a>
        <a v-else slot="extra">
            <template>
            <a-popconfirm title="你确定保存修改吗？" okText="yes" cancelText="No" @cancel='cancle' @confirm='submitSaveBaseInfo(form)'>
                <a href="#" style="padding-right:10px">保存</a>
                <a @click="cancle">取消</a>
            </a-popconfirm>
            </template>
        </a>
        <div v-if="showmsg">
            <a-row style="margin-bottom: 25px;">
            <a-col :span="8">
                <span class="subTitle">API名称：</span>
                {{form.apiName}}
            </a-col>
            <a-col :span="8"><span class="subTitle">接口描述：</span><span v-if="form.apiDesc">{{form.apiDesc}}</span><span style="color: gray;font-size: 10px;" v-else>选填</span></a-col>
            <a-col :span="8"><span class="subTitle">接入系统：</span>{{form.ofUpstreamName}}</a-col>
            </a-row>
            <a-row>
            <a-col :span="8"><span class="subTitle">调用方式：</span><span v-if="this.apiDetailRes.data.apiListInfo.requestType">{{this.apiDetailRes.data.apiListInfo.requestType}}</span><span style="color: gray;font-size: 10px;" v-else>必填</span></a-col>
            <a-col :span="8"><span class="subTitle">报文编码：</span><span v-if="this.apiDetailRes.data.apiListInfo.msgEncode">{{this.apiDetailRes.data.apiListInfo.msgEncode}}</span><span style="color: gray;font-size: 10px;" v-else>必填</span></a-col>
            <a-col :span="8"><span class="subTitle">请求Path：</span>{{form.requestPath}}</a-col>
            </a-row>
        </div>
        <div v-else>
            <a-row style="margin-bottom: 25px;">
                <div style="display: flex; justify-content: space-between;">
                    <div style="display: flex; align-items: center; width: 50%;">
                        <div style="min-width: 80px;">
                            <span class="signTitle">*</span>
                            <span class="subTitle">API名称：</span>
                        </div>
                        <a-input placeholder="请输入接口名称" style="width: 70%; border: 0;"  v-model="form.apiName"/>
                    </div>
                    <div style="display: flex; align-items: center;width: 50%;">
                        <div style="min-width: 80px;">
                            <span class="subTitle" style="margin-left: 10px;">接口描述：</span>
                        </div>
                        <a-input placeholder="请输入" style="width: 70%; border: 0;" v-model="form.apiDesc"/>
                    </div>
                </div>
            </a-row>
            <a-row style="margin-bottom: 25px;">
                <div style="display: flex; justify-content: space-between;">
                    <div style="display: flex; align-items: center; width: 50%;">
                        <div style="min-width: 80px;">
                            <span class="signTitle">*</span>
                            <span class="subTitle">接入系统：</span>
                        </div>
                        <div>
                            <a-select
                                    showSearch
                                    placeholder="请选择"
                                    optionFilterProp="children"
                                    style="width: 150px; border: 0; text-align: right;"
                                    @focus="handleFocus"
                                    @blur="handleBlur"
                                    @change="handleChange"
                                    :filterOption="filterOption"
                                    :defaultValue="form.ofUpstreamName"
                            >
                                <a-select-option v-for="(item,index) in apiGroupList" :key="index">
                                    {{item.name}}
                                </a-select-option>
                            </a-select>
                        </div>
                    </div>
                    <div style="display: flex; align-items: center;width: 50%;">
                        <div style="min-width: 80px;">
                            <span class="signTitle">*</span>
                            <span class="subTitle">请求Path：</span>
                        </div>
                        <a-input placeholder="请输入" style="width: 70%; border: 0;" v-model="form.requestPath"/>
                    </div>
                </div>
            </a-row>
            <a-row style="margin-bottom: 25px;">
                <div style="display: flex; justify-content: space-between;">
                    <div style="display: flex; align-items: center; width: 50%;">
                        <div style="min-width: 80px;">
                            <span class="signTitle">*</span>
                            <span class="subTitle">调用方式：</span>
                        </div>
                        <a-radio-group name="radioGroup" @change='changeRequestType'>
                            <a-radio :value="1">GET</a-radio>
                            <a-radio :value="2">POST</a-radio>
                            <a-radio :value="3">PUT</a-radio>
                            <a-radio :value="4">DELETE</a-radio>
                            <a-radio :value="5">HEAD</a-radio>
                        </a-radio-group>
                    </div>
                    <div style="display: flex; align-items: center;width: 50%;">

                        <div style="min-width: 80px;">
                            <span class="signTitle">*</span>
                            <span class="subTitle">报文编码：</span>
                        </div>
                        <a-radio-group name="radioGroup"  @change='changeCode'>
                            <a-radio :value="1">UTF-8</a-radio>
                            <a-radio :value="2">GBK</a-radio>
                        </a-radio-group>
                    </div>
                </div>
            </a-row>
        </div>
        </a-card>
        <!-- 高级配置卡片展示 -->
        <a-card title="高级配置" style="text-align: left;" :style="{ marginTop: '16px' }">
        <a href="#" slot="extra">修改</a>
         <a-row>
            <a-col :span="8"><span class="subTitle">签名校验：</span>是</a-col>
            <a-col :span="8"><span class="subTitle">开放JSONP：</span>否</a-col>
            <a-col :span="8"><span class="subTitle">超时时间(ms)：</span>1500</a-col>
            </a-row>
        </a-card>
        <!-- 限流配置卡片展示 -->
        <a-card title="限流配置" style="text-align: left;" :style="{ marginTop: '16px' }">
        <a v-if="showLimiting" @click="changeShowLimiting" slot="extra">修改</a>
        <a v-else slot="extra">
            <template>
            <a-popconfirm title="你确定保存修改吗？" okText="yes" cancelText="No" @cancel='cancleLimiting' @confirm='submitLimiting(config)'>
                <a href="#" style="padding-right:10px">保存</a>
                <a @click="cancleLimiting">取消</a>
            </a-popconfirm>
            </template>
        </a>
        <div v-if="showLimiting">
            <a-row>
                <a-col :span="4"><span class="subTitle">限流模式：</span>{{this.limitData.enabled||this.openLimitting?'开启':'关闭'}}</a-col>
                <a-col :span="4" v-if="this.limitData.enabled&&this.limitData.config.year"><span class="subTitle">年：</span>{{this.limitData.config.year}}/year</a-col>
                <a-col :span="4" v-if="this.limitData.enabled&&this.limitData.config.month"><span class="subTitle">月：</span>{{this.limitData.config.month}}/month</a-col>
                <a-col :span="4" v-if="this.limitData.enabled&&this.limitData.config.day"><span class="subTitle">日：</span>{{this.limitData.config.day}}/day</a-col>
                <a-col :span="4" v-if="this.limitData.enabled&&this.limitData.config.hour"><span class="subTitle">时：</span>{{this.limitData.config.hour}}/hour</a-col>
                <a-col :span="4" v-if="this.limitData.enabled&&this.limitData.config.minute"><span class="subTitle">分：</span>{{this.limitData.config.minute}}/minute</a-col>
                <a-col :span="4" v-if="this.limitData.enabled&&this.limitData.config.second"><span class="subTitle">秒：</span>{{tthis.limitData.config.second}}/second</a-col>
            </a-row>
        </div>
        <div v-else>
            <span>限流模式：</span>
            <a-radio-group @change="onChangeLimiting" v-model="value">
            <a-radio :value="1">关闭</a-radio>
            <a-radio :value="2">开启</a-radio>
            </a-radio-group>
            <div v-if="value===2">
                <a-form layout="inline" :form='config'>
                    <a-form-item label="年">
                        <a-input placeholder="请输入" v-model="config.year"/>
                    </a-form-item>
                    <a-form-item label="月">
                        <a-input placeholder="请输入" v-model="config.month"/>
                    </a-form-item>
                    <a-form-item label="日">
                        <a-input placeholder="请输入" v-model="config.day"/>
                    </a-form-item>
                    <a-form-item label="时">
                        <a-input placeholder="请输入" v-model="config.hour"/>
                    </a-form-item>
                    <a-form-item label="分">
                        <a-input placeholder="请输入" v-model="config.minute"/>
                    </a-form-item>
                    <a-form-item label="秒">
                        <a-input placeholder="请输入" v-model="config.second"/>
                    </a-form-item>
                </a-form>
            </div>
        </div>
        </a-card>
        <!-- 缓存配置卡片展示 -->
        <a-card title="缓存配置" style="text-align: left;" :style="{ marginTop: '16px' }">
            <a v-if="showCache" @click="changeShowCache" slot="extra">修改</a>
            <a v-else slot="extra">
                <template>
                <a-popconfirm title="你确定保存修改吗？" okText="yes" cancelText="No" @cancel='cancleCache' @confirm='submitCache(cacheSecond)'>
                    <a href="#" style="padding-right:10px">保存</a>
                    <a @click="cancleCache">取消</a>
                </a-popconfirm>
                </template>
            </a>
        <div v-if="showCache">
            <a-row>
                <a-col :span="4"><span class="subTitle">结果缓存：</span>{{this.cacheData.enabled==='true'?'开启':'关闭'}}</a-col>
                 <a-col :span="4" v-if="this.cacheData.enabled"><span class="subTitle">缓存时间：</span>{{this.cacheData.config.cache_ttl}}<span>/s</span></a-col>
            </a-row>
        </div>
        <div v-else>
            <a-row>
                <a-col style="margin-top: 6px;" :span="8"><span class="subTitle">结果缓存：</span>
                <a-switch checkedChildren="开" unCheckedChildren="关" :defaultChecked='cacheSwitch' @change="onChangeCache"/>
                </a-col>
                <a-col :span="8" v-if="showCacheInput">
                <a-form layout="inline">
                    <a-form-item label="缓存时间(s)：">
                        <a-input placeholder="请输入" v-model="cacheSecond"/>
                    </a-form-item>
                </a-form>
                </a-col>
            </a-row>
        </div>
        </a-card>
        <!-- 参数设置卡片展示 -->
        <a-card title="参数设置" style="text-align: left;" :style="{ marginTop: '16px' }">
            <a v-if="showNoun" @click="changeShowNoun" slot="extra">修改</a>
            <a v-else slot="extra">
                <template>
                <a-popconfirm title="你确定保存修改吗？" okText="yes" cancelText="No" @cancel='cancleNoun' @confirm='submitNoun(moadlListRequestParam)'>
                    <a href="#" style="padding-right:10px">保存</a>
                    <a @click="cancleNoun">取消</a>
                </a-popconfirm>
                </template>
            </a>
        <div v-if="showNoun">
            <h3>请求参数<small style="font-size: 75%;font-weight: 400;line-height: 1; color: #777; margin-left: 10px;">请指定请求Body的数据模型及Content-Type</small></h3>
            <a-table
                :columns="requestColums"
                :rowKey="record => record.login.uuid"
                :dataSource="requestData"
            >
            </a-table>
            <section style="margin-top:40px">
            <div class="contnet-title">
                <h3 style="float: left;">请求Body<small style="font-size: 75%;font-weight: 400;line-height: 1; color: #777; margin-left: 10px;">请指定请求Body的数据模型及Content-Type</small></h3>
            </div>
            <a-row style="margin-top:10px">
                <a-col :span="12"><span style="font-weight:bold">请求Body类型:</span>{{requestName}}</a-col>
                <a-col :span="12"><span style="font-weight:bold">报文类型:</span>application/json</a-col>
            </a-row>
        </section>
        <section style="margin-top:40px">
            <div class="contnet-title">
                <h3 style="float: left;">响应结果<small style="font-size: 75%;font-weight: 400;line-height: 1; color: #777; margin-left: 10px;">请指定响应结果的类型</small></h3>
            </div>
            <a-row style="margin-top:10px">
                <a-col :span="12"><span style="font-weight:bold">响应结果类型:</span>{{responseName}}</a-col>
            </a-row>
        </section>
        </div>
        <div v-else>
            <h3>请求参数<small style="font-size: 75%;font-weight: 400;line-height: 1; color: #777; margin-left: 10px;">请指定请求Body的数据模型及Content-Type</small></h3>
            <a-table
                :columns="requestColums"
                :rowKey="record => record.login.uuid"
                :dataSource="requestData"
            >
            </a-table>
            <section style="margin-top:40px">
            <div class="contnet-title">
                <h3 style="float: left;">请求Body<small style="font-size: 75%;font-weight: 400;line-height: 1; color: #777; margin-left: 10px;">请指定请求Body的数据模型及Content-Type</small></h3>
            </div>
            <a-row style="margin-top:10px">
                <a-col :span="12"><span style="font-weight:bold">请求Body类型:</span>
                <a-select  style="width: 200px" @change="handleChangeBodyType">
                    <a-select-option v-for="(item,index) in modalList" :key="index">
                        {{item.modelName}}
                    </a-select-option>
                </a-select>
                </a-col>
                <a-col :span="12"><span style="font-weight:bold">报文类型:</span>
                    <a-select style="width: 200px" @change="handleChangeContentType">
                    <a-select-option v-for="(item,index) in requestType" :key="index">
                        {{item}}
                    </a-select-option>
                    </a-select>
                </a-col>
            </a-row>
        </section>
        <section style="margin-top:40px">
            <div class="contnet-title">
                <h3 style="float: left;">响应结果<small style="font-size: 75%;font-weight: 400;line-height: 1; color: #777; margin-left: 10px;">请指定响应结果的类型</small></h3>
            </div>
            <a-row style="margin-top:10px">
                <a-col :span="12"><span style="font-weight:bold">响应结果类型:</span>
                    <a-select  style="width: 200px" @change="handleChangeResponseResult">
                    <a-select-option v-for="(item,index) in modalList" :key="index">
                        {{item.modelName}}
                    </a-select-option>
                    </a-select>
                </a-col>
            </a-row>
        </section>
        </div>
        </a-card>
    </div>
</template>
<script>
import {saveBaseInfo,searchApiGroup,createPlugin,isEffectApi,apiDetail,getModalList,configApiParam} from './../service/api'
const requestColums = [
    {
      title: '参数名称',
      dataIndex: 'name',
    },
    {
      title: '参数位置',
      dataIndex: 'position',
      width: '20%',
    },
    {
      title: '类型',
      dataIndex: 'type',
    },
    {
      title: '默认值',
      dataIndex: 'defaultValue',
    },
    {
      title: '描述',
      dataIndex: 'des',
    },
  ];

export default {
    data(){
        return{
            showmsg:true,
            form:{},
            showLimiting:true,
            showCache:true,
            value: 1,
            requestName:'',
            responseName:'',
            requestColums,
            requestData:[],
            showTitle:true,
            apiGroupList:{},
            config:{},
            checked:false,
            apiDetailRes:{},
            pluginId:'',
            cachePluginId:null,
            ratePluginId:null,
            openLimitting:"",
            showCacheInput:false,
            cacheSwitch:false,
            showNoun:true,
            cacheSecond:'',
            cacheData:{},
            limitData:{},
            requestType:[
                'application/json','application/x-www-form-urlencode','application/protobuf'
            ],
            modalList:[],
            moadlListRequestParam:{
                api_id:'',
                model_info:[
                {
                model_id:'',
                model_name:'',
                param_type:"request",
                content_type:'',
                },
                {
                model_id:'',
                model_name:'',
                param_type:"response",
                content_type:null
                }
                ],
                request_type:'POST',
            }
        }
    },
    async created(){
        this.form = this.$route.params
        this.form.status==='0'?this.checked=false:this.checked=true
        let param = {}
        param.api_id = this.form.apiId
        console.log(this.$route.params)
        const apiGroupList = await searchApiGroup({})
        this.apiDetailRes = await apiDetail(param)
        console.log(JSON.stringify(this.apiDetailRes))
        this.requestName = this.apiDetailRes.data.paramsModel.postParamModel.model_info[0].model_name?this.apiDetailRes.data.paramsModel.postParamModel.model_info[0].model_name:''
        this.responseName = this.apiDetailRes.data.paramsModel.postParamModel.model_info[1].model_name?this.apiDetailRes.data.paramsModel.postParamModel.model_info[1].model_name:''
        this.apiGroupList  = apiGroupList.data
        let arr = this.apiDetailRes.data.pluginsInfo
        var _this = this 
        for(var i=0;i<arr.length;i++){
            if(arr[i].pluginName==='proxy-cache'){
                 _this.cachePluginId = arr[i].pluginId
                 _this.cacheData = arr[i]
                 console.log("cacheData"+JSON.stringify(_this.cacheData))
            }else if(arr[i].pluginName==='rate-limiting'){
                 _this.ratePluginId = arr[i].pluginId
                 _this.limitData = arr[i]
                 console.log("limitData"+JSON.stringify(_this.limitData))
            }
        }
        const modalList = await getModalList()
        this.modalList = modalList.data
    },
    mounted(){
        this.form = this.$route.params
    },
    methods:{
        onChangeCache(checked){
            this.showCacheInput = checked
            console.log(`a-switch to ${checked}`);
        },
        async submitCache(num){
            console.log(num)
            let param = {}
            param.config = {}
            param.service_id = this.form.serviceId
            param.plugin_name = 'proxy-cache'
            param.plugin_type = "1",
            param.config.strategy='memory'
            param.plugin_id = this.cachePluginId
            param.enabled = this.showCacheInput
            param.config.cache_ttl = num
            param.api_id = this.form.apiId
            console.log(JSON.stringify(param))
            const res = await createPlugin(param)
            this.showCache = !this.showCache
        },
        async submitNoun(obj){
            console.log("========"+JSON.stringify(obj))
            if(obj.model_info[1]&&obj.model_info[0].model_id===obj.model_info[1].model_id){
                alert("请求、响应请选择不同的数据模型")
            }else{
                const res = await configApiParam(obj)
                this.showNoun = !this.showNoun
            }
        },
        openClose(checked){
            let param = {}
            param.service_id = this.form.serviceId;
            param.operate_type = this.form.operateType;
            param.api_id = this.form.apiId
            checked===false?param.flag = '02':param.flag = '01'
            const res = isEffectApi(param)
        },
        changeRequestType(e){
            console.log(JSON.stringify(e))
            var _this = this;
            switch(e.target.value){
            case 1:
             _this.form.request_type = 'GET'
            break;
            case 2:
             _this.form.request_type = 'POST'
            break;
            case 3:
             _this.form.request_type = 'PUT'
            break;
            case 4:
             _this.form.request_type = 'DELETE'
            break;
            case 5:
             _this.form.request_type = 'HEAD'
            break;
        }
        console.log(JSON.stringify(this.form))
        },
        changeCode(e){
            if(e.value===1){
                this.form.msg_encode = 'UTF-8'
            }else{
                this.form.msg_encode = 'GBK'
            }
        },
        showInputTitle(){
            this.showTitle = !this.showTitle
        },
        onChangeLimiting(e) {
            console.log('radio checked', e.target.value);
            this.openLimitting = e.target.value
        },
        async submitLimiting(e){
            let param = {}
            param.api_id = this.form.apiId
            param.service_id = this.form.serviceId
            param.plugin_name = 'rate-limiting'
            param.plugin_type = "1",
            param.plugin_id = this.ratePluginId
            param.enabled = this.openLimitting===1?'false':'true'
            param.config = e
            console.log(JSON.stringify(param))
            const res = await createPlugin(param)
            this.showLimiting = !this.showLimiting
        },
        submit(){
            console.log("submit")
        },
        changeShow(){
            this.showmsg = !this.showmsg
        },
        cancle(){
            this.showmsg = !this.showmsg
        },
        changeShowLimiting(){
            this.showLimiting = !this.showLimiting
        },
        changeShowCache(){
            this.showCache = !this.showCache
        },
        changeShowNoun(){
            this.showNoun = !this.showNoun
        },
        cancleNoun(){
            this.showNoun = !this.showNoun
        },
        cancleCache(){
            this.showCache = !this.showCache
        },
        cancleLimiting(){
            this.showLimiting = !this.showLimiting
        },
        submitSaveBaseInfo(e){
            console.log(JSON.stringify(this.form));
            let param = {}
            param.api_type = 'http'
            param.api_id = this.form.apiId 
            param.service_id = this.form.serviceId
            param.api_name = this.form.apiName
            param.api_desc = this.form.apiDesc
            param.of_upstream_name = this.form.ofUpstreamName
            param.of_upstream_url = this.form.ofUpstreamUrl
            param.request_type = this.form.request_type
            param.msg_encode = this.form.msg_encode
            param.request_path  = this.form.requestPath
            // this.form.request_type = 'GET'
            // this.form.msg_encode='UTF-8'
            console.log(JSON.stringify(param))
            const res = saveBaseInfo(param)
            this.showmsg =!this.showmsg
        },
        backPage(){
            this.$router.go(-1)
        },
        handleChangeBodyType(value){
            this.moadlListRequestParam.model_info[0].model_id = this.modalList[value].modelId
            this.moadlListRequestParam.model_info[0].model_name = this.modalList[value].modelName
            this.moadlListRequestParam.api_id = this.form.apiId
            console.log(JSON.stringify(this.moadlListRequestParam))
        },
        handleChangeContentType(value){
            this.moadlListRequestParam.model_info[0].content_type = this.requestType[value]
            console.log(JSON.stringify(this.moadlListRequestParam))
        },
        handleChangeResponseResult(value){
            this.moadlListRequestParam.model_info[1].model_id = this.modalList[value].modelId
            this.moadlListRequestParam.model_info[1].model_name = this.modalList[value].modelName
            console.log(JSON.stringify(this.moadlListRequestParam))
        },
        handleChange(value,option) {
            this.form.of_upstream_url = option.context.apiGroupList[value].protocol +'://'+ option.context.apiGroupList[value].host +':'+ option.context.apiGroupList[value].port
        },
        handleBlur() {
            console.log('blur');
        },
        handleFocus() {
            console.log('focus');
        },
        filterOption(input, option) {
            return (
                option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0
            );
        },

    }
}
</script>
<style scoped>
.contnet-title{
    float: left;
    width: 100%;
}
.ant-card-head-title{
        color: #3C5269; font-size:16px;
        /*padding: 0;*/
    }
    .ant-card-extra{
        padding: 0;
    }
    .ant-card-head{
        padding: 25px;
    }
    .signTitle{
        color: #E02020;
        font-size: 14px;
    }
    .subTitle{
        font-weight:bold;color: #3C5269;
    }
    .ant-select-selection--single{
        border: 0 !important;
    }

</style>