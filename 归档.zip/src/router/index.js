import Vue from 'vue'
import Router from 'vue-router'
import login from './../page/login'
import balanceinquiry from './../page/balanceinquiry'
import home from './../component/layout/sliderBar'


Vue.use(Router)
  
// const list = sessionStorage.getItem('list')
// alert(JSON.stringify(JSON.parse(list)[0]))
// const dynamicRoute = JSON.parse(list)[0]
const router =  new Router({
  routes: [
    {
      path: '/',
      name: 'balanceinquiry',
      component: balanceinquiry
    },
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/home',
      name: 'home',
      component: home,
      redirect:'/gateway',
      meta: { 
        title: '首页',
        requireAuth: true
      },
      children:[
        {
          path:'/gateway',
          name:'gateway',
          component: ()=> import('@/page/gateway'),
          meta:{
            requireAuth:true
          }
        },
        {
          path:'/edit',
          name:'edit',
          component: ()=> import('@/page/edit'),
          meta:{
            requireAuth:true
          }
        },
        {
          path:'/createModal',
          name:'createModal',
          component: ()=> import('@/page/createModal'),
          meta:{
            requireAuth:true
          }
        },
        {
          path:'/user',
          name:'user',
          component: ()=> import('@/page/user')
        }
      ],
    },
    // dynamicRoute,
    {
      path: '*',
      component: Error,
      name: 'error'
    },
  ]
})
 
export default router 

// //路由权限token拦截
// router.beforeEach((to, from, next) => {
//   if (to.meta.requireAuth) { // 判断该路由是否需要登录权限
//     if (sessionStorage.getItem("token") == 'true') { // 判断本地是否存在token
//       next()
//     } else {
//       // 未登录,跳转到登陆页面
//       next({
//         path: '/login'
//       })
//     }
//   }else {
//     if(sessionStorage.getItem("token") == 'true'){
//       next('/');
//     }else{
//       next('/home');
//     }
//   }
// });
